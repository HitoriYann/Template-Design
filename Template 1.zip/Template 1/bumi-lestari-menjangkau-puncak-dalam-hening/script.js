// ===== DATA DESTINASI (4 GUNUNG) - GAMBAR OTOMATIS =====
const destinations = [
    {
        name: "Gunung Semeru",
        badge: "Atap Jawa",
        desc: "Puncak tertinggi di Jawa dengan pesona Ranu Kumbolo & kawah Mahameru yang legendaris.",
        img: "Gunung Semeru.jpeg",
        link: "#"
    },
    {
        name: "Gunung Rinjani",
        badge: "Lanskap Megah",
        desc: "Keindahan Danau Segara Anak dan kaldera Gunung Barujari yang tak tertandingi.",
        img: "Gunung Rinjani.jpeg",
        link: "#"
    },
    {
        name: "Gunung Prau",
        badge: "Sunrise Spot",
        desc: "Trek ramah pemula dengan golden sunrise & hamparan bukit teletubbies yang ikonik.",
        img: "Gunung Prau.jpeg",
        link: "#"
    },
    {
        name: "Gunung Bromo",
        badge: "Ikonic",
        desc: "Keindahan lautan pasir dan kaldera aktif dengan pemandangan matahari terbit yang legendaris.",
        img: "Gunung Bromo.jpeg",
        link: "#"
    }
];

// ===== DATA ARTIKEL - GAMBAR OTOMATIS =====
const articles = [
    {
        tag: "Panduan",
        title: "Manajemen Aklimatisasi & AMS",
        desc: "Cara mencegah dan mengatasi penyakit ketinggian di atas 3.000 MDPL.",
        img: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=400&h=400&fit=crop&crop=center"
    },
    {
        tag: "Perlengkapan",
        title: "Checklist Gear Musim Hujan",
        desc: "Daftar peralatan ultralight dan waterproof wajib masuk carrier.",
        img: "https://images.unsplash.com/photo-1537565266759-34bbc16be345?w=400&h=400&fit=crop&crop=center"
    },
    {
        tag: "Etika Alam",
        title: "Prinsip Leave No Trace",
        desc: "7 kaidah utama menjaga keseimbangan ekosistem Atap Jawa.",
        img: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=400&h=400&fit=crop&crop=center"
    }
];

// ===== RENDER DESTINASI =====
function renderDestinations() {
    const grid = document.getElementById('destinationGrid');
    if (!grid) return;

    grid.innerHTML = destinations.map(dest => `
        <div class="card">
            <img 
                src="${dest.img}" 
                alt="${dest.name}" 
                class="card-img-circle" 
                loading="lazy"
                onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Crect width=%22100%22 height=%22100%22 fill=%22%232d6a4f%22/%3E%3Ctext x=%2250%22 y=%2255%22 text-anchor=%22middle%22 fill=%22%23fff%22 font-size=%2220%22 font-family=%22Arial%22%3E🏔️%3C/text%3E%3C/svg%3E'"
            />
            <span class="badge">${dest.badge}</span>
            <h3>${dest.name}</h3>
            <p>${dest.desc}</p>
            <a href="${dest.link}" class="card-link">
                Lihat Detail Trek <i class="fas fa-arrow-right"></i>
            </a>
        </div>
    `).join('');
}

// ===== RENDER ARTIKEL =====
function renderArticles() {
    const grid = document.getElementById('articleGrid');
    if (!grid) return;

    grid.innerHTML = articles.map(article => `
        <div class="article-card">
            <img 
                src="${article.img}" 
                alt="${article.title}" 
                class="article-img" 
                loading="lazy"
                onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Crect width=%22100%22 height=%22100%22 fill=%22%232d6a4f%22/%3E%3Ctext x=%2250%22 y=%2255%22 text-anchor=%22middle%22 fill=%22%23fff%22 font-size=%2220%22 font-family=%22Arial%22%3E📖%3C/text%3E%3C/svg%3E'"
            />
            <span class="tag">${article.tag}</span>
            <h4>${article.title}</h4>
            <p>${article.desc}</p>
        </div>
    `).join('');
}

// ===== HAMBURGER MENU =====
function initHamburger() {
    const hamburger = document.getElementById('hamburger');
    const nav = document.querySelector('nav');

    if (hamburger && nav) {
        hamburger.addEventListener('click', () => {
            nav.classList.toggle('active');
            const icon = hamburger.querySelector('i');
            icon.className = nav.classList.contains('active') 
                ? 'fas fa-times' 
                : 'fas fa-bars';
        });

        document.addEventListener('click', (e) => {
            const header = document.querySelector('header');
            if (header && !header.contains(e.target)) {
                nav.classList.remove('active');
                const icon = hamburger.querySelector('i');
                icon.className = 'fas fa-bars';
            }
        });
    }
}

// ===== SMOOTH SCROLL =====
function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            const target = document.querySelector(targetId);
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
}

// ===== INTERSECTION OBSERVER =====
function initObserver() {
    const elements = document.querySelectorAll('.card, .program-item, .article-card');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

    elements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(25px)';
        el.style.transition = 'opacity 0.7s ease, transform 0.7s ease';
        observer.observe(el);
    });
}

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
    renderDestinations();
    renderArticles();
    initHamburger();
    initSmoothScroll();
    initObserver();
});