document.addEventListener("DOMContentLoaded", function () {
  // Smooth Scroll saat mengklik Navigasi Menu
  const links = document.querySelectorAll('.nav-links a, .btn-primary');

  for (const link of links) {
    link.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      
      if (targetId && targetId.startsWith('#')) {
        e.preventDefault();
        const targetElement = document.querySelector(targetId);

        if (targetElement) {
          window.scrollTo({
            top: targetElement.offsetTop - 70, // offset header sticky
            behavior: 'smooth'
          });
        }
      }
    });
  }

  // Efek Bayangan pada Header saat di-scroll
  const header = document.querySelector('.header');
  window.addEventListener('scroll', function () {
    if (window.scrollY > 40) {
      header.style.boxShadow = "0 4px 12px rgba(0,0,0,0.08)";
    } else {
      header.style.boxShadow = "none";
    }
  });
});