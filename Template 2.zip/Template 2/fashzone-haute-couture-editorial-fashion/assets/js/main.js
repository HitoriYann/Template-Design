/* ==========================================================================
   FASHZONE — MAIN JAVASCRIPT LOGIC
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initNavbar();
  initLanguageSwitcher();
  initRunwaySlider();
  initScrollspy();
  initCategoryFilters();
  initModalSystem();
  initContactForm();
});

/* --------------------------------------------------------------------------
   1. NAVBAR, STICKY & MOBILE ACCORDION LOGIC
   -------------------------------------------------------------------------- */
function initNavbar() {
  const navbar = document.querySelector('.navbar');
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navLinks = document.querySelector('.nav-links');
  const navOverlay = document.querySelector('.nav-overlay');
  const dropdownItems = document.querySelectorAll('.nav-item.has-dropdown');

  // Sticky Navbar on Scroll
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  // Mobile Hamburger Toggle
  function toggleMobileMenu() {
    if (!mobileToggle || !navLinks) return;
    const isActive = mobileToggle.classList.toggle('active');
    navLinks.classList.toggle('active');
    if (navOverlay) {
      navOverlay.classList.toggle('active');
    }
    document.body.style.overflow = isActive ? 'hidden' : '';
  }

  function closeMobileMenu() {
    if (!mobileToggle || !navLinks) return;
    mobileToggle.classList.remove('active');
    navLinks.classList.remove('active');
    if (navOverlay) {
      navOverlay.classList.remove('active');
    }
    document.body.style.overflow = '';
  }

  if (mobileToggle) {
    mobileToggle.addEventListener('click', toggleMobileMenu);
  }

  if (navOverlay) {
    navOverlay.addEventListener('click', closeMobileMenu);
  }

  // Mobile Accordion Dropdowns
  dropdownItems.forEach(item => {
    const link = item.querySelector('.nav-link');
    if (link) {
      link.addEventListener('click', (e) => {
        if (window.innerWidth <= 992) {
          // Toggle accordion on mobile/tablet
          e.preventDefault();
          item.classList.toggle('accordion-open');
        }
      });
    }
  });

  // Close mobile drawer when clicking any nav link or dropdown link
  const allNavAnchors = document.querySelectorAll('.nav-links a:not(.dropdown-toggle), .dropdown-menu a');
  allNavAnchors.forEach(anchor => {
    anchor.addEventListener('click', () => {
      if (window.innerWidth <= 992) {
        closeMobileMenu();
      }
    });
  });

  // About Read More Toggle Button
  const aboutReadMoreBtn = document.getElementById('aboutReadMoreBtn');
  const aboutExtraContent = document.getElementById('aboutExtraContent');

  if (aboutReadMoreBtn && aboutExtraContent) {
    aboutReadMoreBtn.addEventListener('click', () => {
      aboutExtraContent.classList.toggle('expanded');
    });
  }

}

/* --------------------------------------------------------------------------
   2. RUNWAY REVEAL SLIDER (#beranda)
   -------------------------------------------------------------------------- */
function initRunwaySlider() {
  const slides = document.querySelectorAll('.slide');
  const prevBtn = document.querySelector('.prev-slide-btn');
  const nextBtn = document.querySelector('.next-slide-btn');
  const currentCounter = document.querySelector('.slide-counter .current');
  const spotlight = document.querySelector('.runway-spotlight');

  if (!slides.length) return;

  let currentIndex = 0;
  let isTransitioning = false;
  let autoSlideTimer = null;

  function goToSlide(index) {
    if (isTransitioning || index === currentIndex) return;
    isTransitioning = true;

    // Flash spotlight vignette effect
    if (spotlight) {
      spotlight.classList.add('flashing');
      setTimeout(() => {
        spotlight.classList.remove('flashing');
      }, 400);
    }

    const currentSlide = slides[currentIndex];
    const nextSlide = slides[index];

    // Outgoing slide clip path sweep
    currentSlide.style.clipPath = 'polygon(0 0, 0 0, 0 100%, 0 100%)';
    currentSlide.classList.remove('active');

    // Incoming slide diagonal reveal sweep
    nextSlide.classList.add('active');
    nextSlide.style.clipPath = 'polygon(0 0, 100% 0, 100% 100%, 0 100%)';

    currentIndex = index;

    // Update Counter (01 — 04 format)
    if (currentCounter) {
      currentCounter.textContent = `0${currentIndex + 1}`;
    }

    setTimeout(() => {
      isTransitioning = false;
    }, 700);
  }

  function nextSlide() {
    const nextIndex = (currentIndex + 1) % slides.length;
    goToSlide(nextIndex);
  }

  function prevSlide() {
    const prevIndex = (currentIndex - 1 + slides.length) % slides.length;
    goToSlide(prevIndex);
  }

  if (nextBtn) nextBtn.addEventListener('click', () => { nextSlide(); resetTimer(); });
  if (prevBtn) prevBtn.addEventListener('click', () => { prevSlide(); resetTimer(); });

  function startTimer() {
    autoSlideTimer = setInterval(nextSlide, 5500);
  }

  function resetTimer() {
    clearInterval(autoSlideTimer);
    startTimer();
  }

  startTimer();
}

/* --------------------------------------------------------------------------
   3. SCROLLSPY HIGHLIGHTING
   -------------------------------------------------------------------------- */
function initScrollspy() {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  const observerOptions = {
    root: null,
    rootMargin: '-20% 0px -60% 0px',
    threshold: 0
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('href') === `#${id}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, observerOptions);

  sections.forEach(section => observer.observe(section));
}

/* --------------------------------------------------------------------------
   4. CATEGORY FILTER CHIPS & DROPDOWN FILTER ROUTING
   -------------------------------------------------------------------------- */
function initCategoryFilters() {
  // Handle filter chips within sections
  const sectionsWithFilters = ['#produk', '#aktivitas', '#artikel'];

  sectionsWithFilters.forEach(sectionSelector => {
    const section = document.querySelector(sectionSelector);
    if (!section) return;

    const filterChips = section.querySelectorAll('.chip-btn');
    const items = section.querySelectorAll('[data-category]');

    filterChips.forEach(chip => {
      chip.addEventListener('click', () => {
        const category = chip.getAttribute('data-filter');

        // Toggle active chip button
        filterChips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');

        // Filter items
        items.forEach(item => {
          const itemCat = item.getAttribute('data-category');
          if (category === 'all' || itemCat === category) {
            item.style.display = '';
            item.style.opacity = '1';
          } else {
            item.style.opacity = '0';
            setTimeout(() => {
              item.style.display = 'none';
            }, 200);
          }
        });
      });
    });
  });

  // Handle Navbar Dropdown Clicks (Scroll + Auto-activate category filter)
  const dropdownLinks = document.querySelectorAll('.dropdown-menu a[data-target-filter]');

  dropdownLinks.forEach(dropdownLink => {
    dropdownLink.addEventListener('click', (e) => {
      e.preventDefault();
      const targetSectionId = dropdownLink.getAttribute('href');
      const targetFilterCategory = dropdownLink.getAttribute('data-target-filter');

      // Scroll to section
      const targetSection = document.querySelector(targetSectionId);
      if (targetSection) {
        targetSection.scrollIntoView({ behavior: 'smooth' });

        // Find matching category filter chip and click it
        const matchingChip = targetSection.querySelector(`.chip-btn[data-filter="${targetFilterCategory}"]`);
        if (matchingChip) {
          matchingChip.click();
        }
      }
    });
  });
}

/* --------------------------------------------------------------------------
   5. INTERACTIVE DETAIL MODAL SYSTEM
   -------------------------------------------------------------------------- */
function initModalSystem() {
  const modalOverlay = document.querySelector('.modal-overlay');
  const modalCloseBtn = document.querySelector('.modal-close-btn');
  const modalImg = document.querySelector('.modal-img');
  const modalTag = document.querySelector('.modal-tag');
  const modalTitle = document.querySelector('.modal-title');
  const modalDesc = document.querySelector('.modal-description');
  const modalMeta = document.querySelector('.modal-meta');

  if (!modalOverlay) return;

  // Items that trigger modal
  const modalCards = document.querySelectorAll('.product-card, .event-card, .article-card');

  modalCards.forEach(card => {
    card.addEventListener('click', () => {
      const title = card.getAttribute('data-title') || card.querySelector('h3, h4')?.textContent || 'Detail Koleksi';
      const desc = card.getAttribute('data-desc') || 'Koleksi eksklusif FashZone dirancang dengan material sutra dan wol pilihan, memadukan siluet modern dengan drape kain berkualitas tinggi.';
      const img = card.querySelector('img')?.getAttribute('src') || 'assets/img/product-1.jpg';
      const tag = card.getAttribute('data-tag') || 'FASHZONE EXCLUSIVE';
      const meta = card.getAttribute('data-meta') || '';

      if (modalTitle) modalTitle.textContent = title;
      if (modalDesc) modalDesc.textContent = desc;
      if (modalImg) modalImg.setAttribute('src', img);
      if (modalTag) modalTag.textContent = tag;
      if (modalMeta) modalMeta.textContent = meta;

      modalOverlay.classList.add('active');
      document.body.style.overflow = 'hidden'; // Prevent background scrolling
    });
  });

  function closeModal() {
    modalOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }

  if (modalCloseBtn) modalCloseBtn.addEventListener('click', closeModal);

  // Close on outside overlay click
  modalOverlay.addEventListener('click', (e) => {
    if (e.target === modalOverlay) {
      closeModal();
    }
  });

  // Close on ESC key press
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalOverlay.classList.contains('active')) {
      closeModal();
    }
  });
}

/* --------------------------------------------------------------------------
   6. CONTACT FORM SUBMISSION
   -------------------------------------------------------------------------- */
function initContactForm() {
  const form = document.querySelector('.kontak-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = form.querySelector('button[type="submit"]');
    const originalText = btn.textContent;

    btn.textContent = 'MENGIRIM PESAN...';
    btn.disabled = true;

    setTimeout(() => {
      btn.textContent = 'PESAN TERKIRIM ✓';
      btn.style.backgroundColor = 'var(--champagne-gold)';
      btn.style.color = 'var(--charcoal-ink)';
      form.reset();

      setTimeout(() => {
        btn.textContent = originalText;
        btn.style.backgroundColor = '';
        btn.style.color = '';
        btn.disabled = false;
      }, 3500);
    }, 1200);
  });
}

/* --------------------------------------------------------------------------
   7. MULTI-LANGUAGE (i18n) DICTIONARY & DYNAMIC TRANSLATION LOGIC
   -------------------------------------------------------------------------- */
const translations = {
  id: {
    nav_beranda: 'Beranda',
    nav_tentang: 'Tentang',
    nav_produk: 'Produk',
    nav_aktivitas: 'Aktivitas',
    nav_event_terbaru: 'Fashion Styling Workshop',
    nav_kolaborasi_brand: 'Sewing & Tailoring Class',
    nav_fashion_show: 'Fashion Show',
    nav_artikel: 'Artikel',
    nav_tips_tren: 'Tips & Tren',
    nav_gaya_hidup: 'Gaya Hidup',
    nav_berita_fashion: 'Berita Fashion',
    nav_kontak: 'Kontak',

    hero_tag_1: 'KOLEKSI AUTUMN / WINTER 2026',
    hero_title_1: 'Keanggunan <span>Drape Sutra</span> Dalam Gemulai Merlot',
    hero_desc_1: 'Mahakarya siluet kontemporer yang menggabungkan estetika editorial haute couture dengan kenyamanan bahan silk alami berkualitas tinggi.',
    hero_btn_1: 'JELAJAHI KOLEKSI',

    hero_tag_2: 'TAILORED EDITORIAL EDITION',
    hero_title_2: 'Karakter <span>Struktur</span> & Kilau Champagne Gold',
    hero_desc_2: 'Simbol ketegasan wanita modern melalui potongan blazer presisi tinggi dan detail jahitan terstruktur karya atelier ternama.',
    hero_btn_2: 'LIHAT DETAIL',

    hero_tag_3: 'ROMANTIC DRAPE SERIES',
    hero_title_3: 'Sensualita <span>Dusty Rose</span> & Gerak Kain Pliat',
    hero_desc_3: 'Ekspresi kelembutan yang berani. Gaun bermotif gelombang drape dengan nuansa warna mawar yang pudar namun memikat.',
    hero_btn_3: 'TEMUKAN GAYA',

    hero_tag_4: 'MINIMALIST CAPPER LABELS',
    hero_title_4: 'Esensi <span>Charcoal Ink</span> & Monokrom Sejati',
    hero_desc_4: 'Kemewahan dalam kesederhanaan. Blus sutra bergaris tegas yang menghadirkan wibawa dan karisma tanpa batas.',
    hero_btn_4: 'PESAN ATELIER',

    about_subtitle: 'MANIFESTO ATELIER',
    about_title: 'Filosofi <span>Gerakan Kain</span> & Kebebasan Siluet',
    about_quote: '"Kami tidak sekadar menjahit pakaian; kami memetakan gerakan drape sutra dan mendefinisikan keberanian setiap wanita."',
    about_p1: 'Didirikan dengan visi majalah editorial majemuk, <strong>FashZone</strong> menghadirkan pengalaman berbusana khusus wanita yang merayakan dinamika kain melengkung dan palet warna adibusana yang matang.',
    about_p2: 'Setiap helai karya dibentuk melalui proses perancangan atelier yang teliti — menggabungkan corak Deep Merlot yang berani, kehangatan Champagne Gold, dan tekstur Ivory Silk yang murni.',
    about_p3: 'Melalui komitmen penuh pada keahlian haute couture, tim atelier kami secara konsisten melakukan kurasi kain sutra alami bermutu tinggi dari pengrajin ternama. Setiap eksperimen siluet dirancang untuk memberikan kenyamanan bergerak tanpa mengorbankan estetika keanggunan abad modern.',
    about_btn: 'BACA SELENGKAPNYA',

    produk_subtitle: 'ATELIER SELECTION',
    produk_title: 'Koleksi <span>Busana Pilihan</span>',
    filter_all: 'Semua Koleksi',
    filter_gown: 'Gown & Dress',
    filter_blouse: 'Silk Blouse',
    filter_outer: 'Tailored Outer',
    action_modal: 'Lihat Selengkapnya',

    aktivitas_subtitle: 'GALLERY & EVENTS',
    aktivitas_title: 'Aktivitas <span>& Panggung Runway</span>',
    filter_all_act: 'Semua Aktivitas',
    filter_event_latest: 'Event Terbaru',
    filter_fashion_show: 'Fashion Show',
    filter_brand_collab: 'Kolaborasi Brand',

    artikel_subtitle: 'EDITORIAL MAGAZINE',
    artikel_title: 'Wawasan <span>& Jurnal Mode</span>',
    filter_all_art: 'Semua Artikel',
    filter_tips_trends: 'Tips & Tren',
    filter_lifestyle: 'Gaya Hidup',
    filter_fashion_news: 'Berita Fashion',
    featured_badge: 'ARTIKEL UTAMA',
    action_read_article: 'Baca Artikel',

    kontak_subtitle: 'BOUTIQUE & ATELIER',
    kontak_headline: 'Kunjungi Boutique & Janji Temu Custom',
    kontak_desc: 'Ingin berkonsultasi mengenai gaun pesta kustom atau membutuhkan panduan pengukuran busana adibusana? Tim stilist atelier kami siap melayani Anda di boutique utama FashZone.',
    kontak_label_address: 'Atelier Utama:',
    kontak_val_address: 'PT Elecomp Indonesia,Malang',
    kontak_label_email: 'Email Concierge:',
    kontak_label_phone: 'Layanan:',

    footer_text: 'House of Haute Couture & Editorial Fashion. Didedikasikan untuk wanita berani yang menghargai gerakan drape kain sutra, kualitas jahitan presisi, dan keanggunan abad modern.',
    footer_nav_title: 'NAVIGASI EDITORIAL',
    footer_hours_title: 'WAKTU OPERASIONAL',
    footer_hours_text: 'Senin – Sabtu: 10.00 – 20.00 WIB<br>Minggu: Khusus Janji Temu VIP<br><br>Senopati Atelier, Jakarta',
    footer_copy: 'FashZone by anggita',
    footer_design: 'Design terbaru 2026'
  },
  en: {
    nav_beranda: 'Home',
    nav_tentang: 'About',
    nav_produk: 'Products',
    nav_aktivitas: 'Activities',
    nav_event_terbaru: 'Fashion Styling Workshop',
    nav_kolaborasi_brand: 'Sewing & Tailoring Class',
    nav_fashion_show: 'Fashion Show',
    nav_artikel: 'Articles',
    nav_tips_tren: 'Tips & Trends',
    nav_gaya_hidup: 'Lifestyle',
    nav_berita_fashion: 'Fashion News',
    nav_kontak: 'Contact',

    hero_tag_1: 'AUTUMN / WINTER 2026 COLLECTION',
    hero_title_1: 'Elegance of <span>Silk Drape</span> In Merlot Grace',
    hero_desc_1: 'A contemporary silhouette masterpiece combining editorial haute couture aesthetics with the ultimate comfort of high-quality natural silk.',
    hero_btn_1: 'EXPLORE COLLECTION',

    hero_tag_2: 'TAILORED EDITORIAL EDITION',
    hero_title_2: 'Character of <span>Structure</span> & Champagne Gold Glow',
    hero_desc_2: 'A symbol of modern womens empowerment through high-precision blazer tailoring and structured stitching by renowned ateliers.',
    hero_btn_2: 'VIEW DETAILS',

    hero_tag_3: 'ROMANTIC DRAPE SERIES',
    hero_title_3: 'Sensuality of <span>Dusty Rose</span> & Pleated Fabric Motion',
    hero_desc_3: 'A bold expression of softness. Wave-draped gown featuring muted yet captivating rose hues that move gracefully.',
    hero_btn_3: 'DISCOVER STYLE',

    hero_tag_4: 'MINIMALIST CAPPER LABELS',
    hero_title_4: 'Essence of <span>Charcoal Ink</span> & True Monochrome',
    hero_desc_4: 'Luxury in simplicity. Clean-lined silk blouse delivering timeless charisma, authority, and elegance without limits.',
    hero_btn_4: 'ORDER ATELIER',

    about_subtitle: 'ATELIER MANIFESTO',
    about_title: 'Philosophy of <span>Fabric Motion</span> & Silhouette Freedom',
    about_quote: '"We do not simply sew garments; we map the fluid movement of silk draping and define the empowerment of every woman."',
    about_p1: 'Founded with an editorial magazine vision, <strong>FashZone</strong> delivers exclusive womenswear celebrating fluid fabric curves and refined haute couture palettes.',
    about_p2: 'Every garment is crafted through meticulous atelier design — blending bold Deep Merlot shades, warm Champagne Gold, and pure Ivory Silk textures.',
    about_p3: 'Driven by a dedicated commitment to haute couture craftsmanship, our atelier team curated premium natural silk fabrics from master weavers. Each silhouette experiment is engineered to provide effortless mobility without compromising modern luxury aesthetics.',
    about_btn: 'READ MORE',

    produk_subtitle: 'ATELIER SELECTION',
    produk_title: 'Curated <span>Apparel Collection</span>',
    filter_all: 'All Collections',
    filter_gown: 'Gowns & Dresses',
    filter_blouse: 'Silk Blouses',
    filter_outer: 'Tailored Outerwear',
    action_modal: 'View Details',

    aktivitas_subtitle: 'GALLERY & EVENTS',
    aktivitas_title: 'Activities <span>& Runway Stages</span>',
    filter_all_act: 'All Activities',
    filter_event_latest: 'Latest Events',
    filter_fashion_show: 'Fashion Show',
    filter_brand_collab: 'Brand Collaborations',

    artikel_subtitle: 'EDITORIAL MAGAZINE',
    artikel_title: 'Insights <span>& Fashion Journal</span>',
    filter_all_art: 'All Articles',
    filter_tips_trends: 'Tips & Trends',
    filter_lifestyle: 'Lifestyle',
    filter_fashion_news: 'Fashion News',
    featured_badge: 'FEATURED ARTICLE',
    action_read_article: 'Read Article',

    kontak_subtitle: 'BOUTIQUE & ATELIER',
    kontak_headline: 'Visit Boutique & Custom Appointment',
    kontak_desc: 'Seeking a custom gown consultation or personalized fitting guide? Our atelier stylist team is ready to serve you at the main FashZone boutique.',
    kontak_label_address: 'Main Atelier:',
    kontak_val_address: 'PT Elecomp Indonesia,Malang',
    kontak_label_email: 'Email Concierge:',
    kontak_label_phone: 'Service:',

    footer_text: 'House of Haute Couture & Editorial Fashion. Dedicated to bold women who appreciate silk drape movement, precise tailoring, and modern elegance.',
    footer_nav_title: 'EDITORIAL NAVIGATION',
    footer_hours_title: 'OPERATING HOURS',
    footer_hours_text: 'Monday – Saturday: 10.00 – 20.00 WIB<br>Sunday: VIP Appointments Only<br><br>Senopati Atelier, Jakarta',
    footer_copy: 'FashZone by anggita',
    footer_design: 'Latest 2026 Design'
  }
};

function initLanguageSwitcher() {
  const langBtns = document.querySelectorAll('.lang-btn');
  const savedLang = localStorage.getItem('fashzone_lang') || 'id';

  function applyLanguage(lang) {
    const dict = translations[lang] || translations.id;
    const elements = document.querySelectorAll('[data-i18n]');

    elements.forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) {
        el.innerHTML = dict[key];
      }
    });

    langBtns.forEach(btn => {
      if (btn.getAttribute('data-lang') === lang) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    document.documentElement.lang = lang;
    localStorage.setItem('fashzone_lang', lang);
  }

  langBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const lang = btn.getAttribute('data-lang');
      applyLanguage(lang);
    });
  });

  // Apply saved language on startup
  applyLanguage(savedLang);
}
