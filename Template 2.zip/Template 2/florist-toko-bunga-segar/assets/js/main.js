

// ========== 1. FUNGSI BAHASA ==========
document.addEventListener('DOMContentLoaded', function() {
    // const langButtons = document.querySelectorAll('.language-selector button');
    const langTrigger = document.getElementById('langDropdownTrigger');
    const langMenu = document.getElementById('langDropdownMenu');
    const langLabel = document.getElementById('langDropdownLabel');
    const langOptions = document.querySelectorAll('.lang-option');

    // Data terjemahan lengkap
    const translations = {
        id: {
            // Hero
            heroBadge: '🌿 Fresh & Beautiful',
            heroTitle: 'Bunga Segar Untuk <br><span>Setiap Momen</span>',
            heroDesc: 'Hadiahkan keindahan alam dengan rangkaian bunga segar dari kebun kami. Dikemas dengan cinta untuk membuat hari spesial Anda lebih berkesan.',

            // Navigation
            navHome: 'Beranda',
            navAbout: 'Tentang',
            navActivities: 'Aktivitas ▾',
            navProducts: 'Produk',
            navArticles: 'Artikel ▾',
            navContact: 'Kontak',

            // About
            aboutTag: 'Tentang Kami',
            aboutTitle: 'Menghadirkan Keindahan <br>Alam ke Setiap Rumah',
            aboutDesc: 'Florist adalah toko bunga yang berdedikasi untuk menghadirkan keindahan alam melalui rangkaian bunga segar dan berkualitas. Kami percaya bahwa bunga memiliki kekuatan untuk menyampaikan perasaan dan menciptakan momen yang tak terlupakan.',
            btnText: 'Baca Selengkapnya',
            btnText2: 'Kembali ke Beranda',
            aboutHeroTitle: 'Kami Merangkai <em>Keindahan</em><br>Satu Bunga di Satu Waktu',
            aboutHeroSub: 'Didirikan dengan penuh cinta dan kecintaan pada bunga, Florist hadir untuk menjadikan setiap momen lebih bermakna lewat keindahan alam yang segar.',
            statYears: 'Tahun Pengalaman',
            statCustomers: 'Pelanggan Puas',
            statAwards: 'Penghargaan',
            statVarieties: 'Varietas Bunga',
            badgeExp: 'Tahun Berkarya',
            

            // Activities
            activitiesTag: 'Aktivitas Kami',
            activitiesTitle: 'Pelayanan Terbaik untuk <br>Kebutuhan Bunga Anda',
            activitiesDesc: 'Kami menyediakan berbagai layanan untuk memenuhi kebutuhan bunga Anda, mulai dari rangkaian sederhana hingga dekorasi acara besar.',
            activity1Title: 'Kebun Sendiri',
            activity1Desc: 'Kami memiliki kebun bunga sendiri sehingga kualitas dan kesegaran bunga terjamin.',
            activity2Title: 'Merangkai Bunga',
            activity2Desc: 'Setiap rangkaian dirangkai dengan hati-hati oleh florist profesional kami.',
            activity3Title: 'Pelatihan Merangkai',
            activity3Desc: 'Ikuti workshop merangkai bunga bersama para ahli untuk mengasah kreativitas Anda.',
            activityLink: 'Pelajari lebih →',
            activityDropdown1: '🌸 Workshop Merangkai Bunga',
            activityDropdown2: '💐 Merangkai Bunga',
            activityDropdown3: '💒 Konsultasi Dekorasi Pernikahan',
            activity4Title: 'Dekorasi Acara & Event',
            activity4Desc: 'Wujudkan dekorasi bunga untuk ulang tahun, grand opening, atau acara korporat dengan sentuhan estetik yang berkesan.',

            // Products
            productsTag: 'Koleksi',
            productsTitle: 'Rangkaian Bunga <br>Pilihan Terbaik',
            productsDesc: 'Pilih rangkaian bunga favorit Anda dari berbagai koleksi kami yang indah dan segar.',
            product1Name: 'Buket Mawar Merah',
            product1Desc: 'Rangkaian mawar merah segar dengan aksen baby breath',
            product2Name: 'Buket Tulip Warna',
            product2Desc: 'Buket tulip warna-warni yang ceria dan menyegarkan',
            product3Name: 'Buket Campuran',
            product3Desc: 'Kombinasi berbagai bunga segar dengan warna yang serasi',
            product4Name: 'Buket Lavender',
            product4Desc: 'Buket lavender dengan aroma menenangkan dan tampilan elegan',
            viewDetail: 'Lihat Selengkapnya',

            // Articles
            articlesTag: 'Artikel',
            articlesTitle: 'Inspirasi & Tips <br>Seputar Bunga',
            articlesDesc: 'Temukan berbagai artikel menarik tentang perawatan bunga, kelas merangkai bunga, dan dekorasi untuk berbagai momen spesial',
            article1Category: 'Perawatan',
            article1Title: '5 Cara Merawat Bunga Agar Tetap Segar Lebih Lama',
            article1Desc: 'Pelajari tips sederhana agar bunga potong tetap segar hingga lebih dari satu minggu di rumah.',
            article1Date: '📅 14 Juli 2026',
            article2Category: 'Inspirasi',
            article2Title: 'Rekomendasi Buket Bunga untuk Hadiah Wisuda',
            article2Desc: 'Pilihan buket bunga terbaik yang cocok diberikan kepada keluarga maupun sahabat saat wisuda.',
            article2Date: '📅 12 Juli 2026',
            article3Category: 'Dekorasi',
            article3Title: 'Inspirasi Dekorasi Rumah dengan Bunga Segar',
            article3Desc: 'Jadikan ruangan lebih hidup dan elegan dengan penataan bunga yang tepat.',
            article3Date: '📅 10 Juli 2026',
            articleLink: 'Baca Selengkapnya →',
            articleDropdown1: '📖 Perawatan Bunga',
            articleDropdown2: '💡 Inspirasi Buket',
            articleDropdown3: '🏠 Dekorasi Rumah',

            // Contact
            contactTag: 'Hubungi Kami',
            contactTitle: 'Mari Bicara <br>Tentang Bunga',
            contactDesc: 'Ada pertanyaan atau ingin memesan rangkaian bunga khusus? Hubungi kami dan kami akan dengan senang hati membantu Anda.',
            contactAddress: 'Alamat',
            contactAddressDetail: 'Jl. Danau Amora No.C5 E8, Sawojajar 1, Kota Malang',
            contactPhone: 'Telepon',
            contactPhoneDetail: '+62 812 3456 7890',
            contactEmail: 'Email',
            contactEmailDetail: 'hello@florist.com',

            // Footer
            footerDesc: 'Menghadirkan keindahan alam melalui rangkaian bunga segar dan berkualitas untuk setiap momen spesial Anda.',
            footerQuickLinks: 'Tautan Cepat',
            footerServices: 'Layanan',
            footerService1: 'Rangkaian Bunga',
            footerService2: 'Dekorasi Acara',
            footerService3: 'Pengiriman',
            footerService4: 'Workshop'
        },
        en: {
            // Hero
            heroBadge: '🌿 Fresh & Beautiful',
            heroTitle: 'Fresh Flowers For <br><span>Every Moment</span>',
            heroDesc: 'Give the beauty of nature with fresh flower arrangements from our garden. Packed with love to make your special day more memorable.',

            // Navigation
            navHome: 'Home',
            navAbout: 'About',
            navActivities: 'Activities ▾',
            navProducts: 'Products',
            navArticles: 'Articles ▾',
            navContact: 'Contact',

            // About
            aboutTag: 'About Us',
            aboutTitle: 'Bringing Nature\'s <br>Beauty to Every Home',
            aboutDesc: 'Florist is a flower shop dedicated to bringing the beauty of nature through fresh and quality flower arrangements. We believe that flowers have the power to convey feelings and create unforgettable moments.',
            btnText: 'Read More',
            btnText2: 'Back To Home',
            aboutHeroTitle: 'We Craft <em>Beauty</em><br>One Flower at a Time',
            aboutHeroSub: 'Founded with love and passion for flowers, Florist is here to make every moment more meaningful through the fresh beauty of nature.',
            statYears: 'Years Experience',
            statCustomers: 'Happy Customers',
            statAwards: 'Awards Won',
            statVarieties: 'Flower Varieties',
            badgeExp: 'Years of Craft',

            // Activities
            activitiesTag: 'Our Activities',
            activitiesTitle: 'Best Services for <br>Your Flower Needs',
            activitiesDesc: 'We provide various services to meet your flower needs, from simple arrangements to large event decorations.',
            activity1Title: 'Flower Arrangement Workshop',
            activity1Desc: 'Learn the art of flower arranging with our professional florists and create your own beautiful bouquet for any special occasion.',
            activity2Title: 'Flower Arranging',
            activity2Desc: 'Each arrangement is carefully arranged by our professional florists.',
            activity3Title: 'Wedding Floral Consultation',
            activity3Desc: 'Plan your dream wedding with personalized floral consultations. We will help you choose the perfect flowers and decorations to match your style and budget.',
            activityLink: 'Learn more →',
            activityDropdown1: '🌸 Flower Arrangement Workshop',
            activityDropdown2: '💐 Flower Arranging',
            activityDropdown3: '💒 Wedding Floral Consultation',
            activity4Title: 'Event & Occasion Decoration',
            activity4Desc: 'Bring your birthday, grand opening, or corporate event to life with elegant floral styling.',

            // Products
            productsTag: 'Collection',
            productsTitle: 'Best Flower <br>Arrangements',
            productsDesc: 'Choose your favorite flower arrangements from our beautiful and fresh collections.',
            product1Name: 'Red Rose Bouquet',
            product1Desc: 'Fresh red rose arrangement with baby breath accents',
            product2Name: 'Colorful Tulip Bouquet',
            product2Desc: 'Cheerful and refreshing colorful tulip bouquet',
            product3Name: 'Mixed Bouquet',
            product3Desc: 'Combination of various fresh flowers with harmonious colors',
            product4Name: 'Lavender Bouquet',
            product4Desc: 'Lavender bouquet with calming aroma and elegant appearance',
            viewDetail: 'Show More',

            // Articles
            articlesTag: 'Articles',
            articlesTitle: 'Inspiration & Tips <br>About Flowers',
            articlesDesc: 'Discover various interesting articles about flower care, flower arranging classes, and decorations for various special moments',
            article1Category: 'Care',
            article1Title: '5 Ways to Keep Cut Flowers Fresh Longer',
            article1Desc: 'Learn simple tips to keep cut flowers fresh for more than a week at home.',
            article1Date: '📅 Jul 14, 2026',
            article2Category: 'Inspiration',
            article2Title: 'Flower Bouquet Recommendations for Graduation Gifts',
            article2Desc: 'The best flower bouquet choices suitable for family and friends at graduation.',
            article2Date: '📅 Jul 12, 2026',
            article3Category: 'Decoration',
            article3Title: 'Home Decoration Inspiration with Fresh Flowers',
            article3Desc: 'Make rooms more lively and elegant with proper flower arrangements.',
            article3Date: '📅 Jul 10, 2026',
            articleLink: 'Read More →',
            articleDropdown1: '📖 Flower Care',
            articleDropdown2: '💡 Bouquet Inspiration',
            articleDropdown3: '🏠 Home Decor',

            // Contact
            contactTag: 'Contact Us',
            contactTitle: 'Let\'s Talk <br>About Flowers',
            contactDesc: 'Have questions or want to order a special flower arrangement? Contact us and we will be happy to help you.',
            contactAddress: 'Address',
            contactAddressDetail: 'Jl. Danau Amora No.C5 E8, Sawojajar 1, Malang City',
            contactPhone: 'Phone',
            contactPhoneDetail: '+62 812 3456 7890',
            contactEmail: 'Email',
            contactEmailDetail: 'hello@florist.com',

            // Footer
            footerDesc: 'Bringing the beauty of nature through fresh and quality flower arrangements for every special moment.',
            footerQuickLinks: 'Quick Links',
            footerServices: 'Services',
            footerService1: 'Flower Arrangements',
            footerService2: 'Event Decoration',
            footerService3: 'Delivery',
            footerService4: 'Workshop'
        }
    };

    // Fungsi untuk update semua konten berdasarkan bahasa
    function updateLanguage(lang) {
        const t = translations[lang];
        if (!t) return;

        // Elemen yang menggunakan innerHTML (mengandung tag HTML seperti <br> atau <span>)
        const innerHtmlKeys = [
        'heroTitle', 'aboutTitle', 'activitiesTitle',
        'productsTitle', 'articlesTitle', 'contactTitle',
        'aboutHeroTitle'
];

        // Cari semua elemen dengan data-lang-key dan update
        document.querySelectorAll('[data-lang-key]').forEach(element => {
            const key = element.getAttribute('data-lang-key');
            if (t[key] !== undefined) {
                if (innerHtmlKeys.includes(key)) {
                    element.innerHTML = t[key];
                } else {
                    element.textContent = t[key];
                }
            }
        });
    }


    if (langTrigger && langMenu) {
        langTrigger.addEventListener('click', function (e) {
            e.stopPropagation();
            langMenu.classList.toggle('open');
            langTrigger.classList.toggle('active');
        });

        langOptions.forEach(function (option) {
            option.addEventListener('click', function () {
                const lang = this.getAttribute('data-lang');

                langOptions.forEach(o => o.classList.remove('active'));
                this.classList.add('active');
                langLabel.textContent = lang.toUpperCase();

                langMenu.classList.remove('open');
                langTrigger.classList.remove('active');

                updateLanguage(lang);
            });
        });

        document.addEventListener('click', function (e) {
            if (!langTrigger.contains(e.target) && !langMenu.contains(e.target)) {
                langMenu.classList.remove('open');
                langTrigger.classList.remove('active');
            }
        });
    }
    // ========== 2. FUNGSI TOGGLE MENU ==========
    const menuToggle = document.querySelector('.menu-toggle');
    const mobileMenu = document.querySelector('.mobile-menu');

    if (menuToggle && mobileMenu) {
        menuToggle.addEventListener('click', function() {
            mobileMenu.classList.toggle('active');
            this.textContent = mobileMenu.classList.contains('active') ? '✕' : '☰';
        });

        mobileMenu.querySelectorAll('a:not(.mobile-dropdown-trigger)').forEach(link => {
            link.addEventListener('click', function() {
                mobileMenu.classList.remove('active');
                menuToggle.textContent = '☰';
            });
        });
    }

    // ========== 3. TUTUP MENU SAAT KLIK DI LUAR ==========
    document.addEventListener('click', function(event) {
        const isClickInsideMenu = mobileMenu && mobileMenu.contains(event.target);
        const isClickOnToggle = menuToggle && menuToggle.contains(event.target);

        if (!isClickInsideMenu && !isClickOnToggle && mobileMenu) {
            mobileMenu.classList.remove('active');
            if (menuToggle) menuToggle.textContent = '☰';
        }
    });

    // Smooth navbar hide/show on scroll
    let lastScrollTop = 0;
        const navbar = document.querySelector('.navbar');

    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
        if (window.__disableNavbarHide) {
            navbar.style.transform = 'none';
            return;
        }

        if (scrollTop > lastScrollTop && scrollTop > 100) {
            // Scroll ke bawah - sembunyikan navbar
            navbar.style.transform = 'translateY(-100%)';
         } else {
            // Scroll ke atas - tampilkan navbar
            navbar.style.transform = 'translateY(0)';
        }
        lastScrollTop = scrollTop;
    });

    // ========== 4. HERO SLIDER BACKGROUND ==========
    const heroSlides = document.querySelectorAll('.hero-slide');
    const heroDots = document.querySelectorAll('.hero-dot');

    if (heroSlides.length > 0) {
        let currentIndex = 0;
        const totalSlides = heroSlides.length;
        let slideInterval;

        function goToSlide(index) {
            heroSlides.forEach(function(slide) {
                slide.classList.remove('active');
            });
            
            heroDots.forEach(function(dot) {
                dot.classList.remove('active');
            });

            if (index < 0) {
                currentIndex = totalSlides - 1;
            } else if (index >= totalSlides) {
                currentIndex = 0;
            } else {
                currentIndex = index;
            }

            heroSlides[currentIndex].classList.add('active');
            if (heroDots[currentIndex]) {
                heroDots[currentIndex].classList.add('active');
            }
        }

        function nextSlide() {
            goToSlide(currentIndex + 1);
        }

        function resetInterval() {
            clearInterval(slideInterval);
            slideInterval = setInterval(nextSlide, 5000);
        }

        heroDots.forEach(function(dot, index) {
            dot.addEventListener('click', function() {
                goToSlide(index);
                resetInterval();
            });
        });

        slideInterval = setInterval(nextSlide, 5000);

        const hero = document.querySelector('.hero');
        if (hero) {
            hero.addEventListener('mouseenter', function() {
                clearInterval(slideInterval);
            });

            hero.addEventListener('mouseleave', function() {
                resetInterval();
            });
        }

        console.log('✅ Hero slider started! Total slides: ' + totalSlides);
    } else {
        console.log('❌ Hero slides tidak ditemukan!');
    }

        function toggleReadMore() {
        const moreText = document.getElementById('aboutMoreText');
        const btnText = document.getElementById('btnText');
        const btnIcon = document.getElementById('btnIcon');
        
        if (moreText.style.display === 'none' || moreText.style.display === '') {
            moreText.style.display = 'block';
            moreText.classList.add('show');
            btnText.textContent = 'Sembunyikan';
            btnIcon.classList.add('active');
        } else {
            moreText.style.display = 'none';
            moreText.classList.remove('show');
            btnText.textContent = 'Baca Selengkapnya';
            btnIcon.classList.remove('active');
        }
    
    }

    

        const cursor = document.getElementById("flower-cursor");

        document.addEventListener("mousemove", function(e){

            // Cursor utama selalu mengikuti mouse
            cursor.style.left = e.clientX + "px";
            cursor.style.top = e.clientY + "px";

            // Membuat kelopak yang berguguran
            const petal = document.createElement("span");

            petal.innerHTML = "🌸";

            petal.style.position = "fixed";
            petal.style.left = e.clientX + "px";
            petal.style.top = e.clientY + "px";
            petal.style.pointerEvents = "none";
            petal.style.fontSize = (10 + Math.random()*10) + "px";
            petal.style.zIndex = "9998";
            petal.style.transition = "all 1.5s ease-out";

            document.body.appendChild(petal);

            setTimeout(()=>{

                petal.style.transform =
                    `translate(${Math.random()*80-40}px,80px) rotate(${Math.random()*360}deg)`;

                petal.style.opacity = "0";

            },10);

            setTimeout(()=>{
                petal.remove();
            },1500);

        });

        // ========== TOGGLE DROPDOWN DI DALAM MOBILE MENU (Aktivitas & Artikel) ==========
        document.querySelectorAll('.mobile-dropdown-trigger').forEach(function(trigger) {
            trigger.addEventListener('click', function(e) {
                e.preventDefault(); // jangan langsung loncat scroll, buka dropdown dulu

                const parent = this.closest('.mobile-dropdown');
                const menu = parent.querySelector('.mobile-dropdown-menu');
                const isOpen = menu.classList.contains('open');

                // tutup dropdown mobile lain yang mungkin lagi kebuka
                document.querySelectorAll('.mobile-dropdown-menu.open').forEach(function(openMenu) {
                    if (openMenu !== menu) openMenu.classList.remove('open');
                });

                menu.classList.toggle('open', !isOpen);
            });
        });

        // ========== INTERSECTION OBSERVER ANIMASI REVEAL CARD ==========
        const observerOptions = {
            root: null, // Viewport browser
            rootMargin: '0px 0px -50px 0px', // Trigger saat elemen berjarak 50px dari bawah viewport
            threshold: 0.15 // Trigger saat 15% elemen terlihat
        };

        const cardObserver = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                const card = entry.target;

                if (entry.isIntersecting) {
                    // Berikan staggered delay jika tersimpan di data-delay
                    if (card.dataset.delay) {
                        card.style.transitionDelay = card.dataset.delay;
                    }

                    // Tambahkan class 'active' untuk memicu animasi CSS masuk
                    card.classList.add('active');

                    // Hapus inline transitionDelay setelah animasi selesai agar efek hover tetap responsif tanpa delay
                    setTimeout(function() {
                        if (card.classList.contains('active')) {
                            card.style.removeProperty('transition-delay');
                        }
                    }, 700);
                } else {
                    // Hapus class 'active' saat keluar viewport agar bisa di-trigger ulang berulang kali
                    card.classList.remove('active');
                    card.style.removeProperty('transition-delay');
                }
            });
        }, observerOptions);

        // Cari semua card dan elemen yang perlu dianimasikan
        const cardsToAnimate = document.querySelectorAll('.reveal, .reveal-card, .reveal-left, .reveal-right, .product-card, .article-side-card, .article-featured, .activity-card, .section-header');

        // Kelompokkan elemen berdasarkan parent container untuk staggered transition-delay bertahap
        const containerGroups = new Map();

        cardsToAnimate.forEach(function(card) {
            card.classList.add('reveal-card');

            const parent = card.parentElement;
            if (parent) {
                if (!containerGroups.has(parent)) {
                    containerGroups.set(parent, []);
                }
                containerGroups.get(parent).push(card);
            }

            cardObserver.observe(card);
        });

        // Simpan staggered delay di dataset (0.12s per index dalam grup) untuk di-apply ulang saat scroll masuk
        containerGroups.forEach(function(groupCards) {
            groupCards.forEach(function(card, index) {
                if (!card.className.includes('reveal-delay-')) {
                    card.dataset.delay = (index * 0.12) + 's';
                }
            });
        });

        window.addEventListener('beforeprint', function () {
            // Paksa AOS animation ke kondisi selesai
            document.querySelectorAll('[data-aos]').forEach(el => {
                el.classList.add('aos-animate');
            });
            if (typeof AOS !== 'undefined' && AOS.refresh) {
                AOS.refresh();
            }

            // Paksa semua elemen reveal (IntersectionObserver custom) ke kondisi visible
            document.querySelectorAll('.reveal, .reveal-card, .reveal-left, .reveal-right, .product-card, .article-side-card, .article-featured, .activity-card, .section-header')
                .forEach(el => {
                    el.classList.add('active', 'visible', 'is-visible', 'in-view');
                    el.style.opacity = '1';
                    el.style.transform = 'none';
                });

            // Matikan efek hide-on-scroll navbar (transform translateY(-100%))
            const navbar = document.querySelector('.navbar');
            if (navbar) {
                navbar.style.transform = 'none';
            }

            // Paksa iframe peta lazy-load dimuat
            document.querySelectorAll('iframe[loading="lazy"]').forEach(iframe => {
                iframe.loading = 'eager';
            });

            // Paksa semua gambar lazy-load langsung dimuat
            document.querySelectorAll('img[loading="lazy"]').forEach(img => {
                img.loading = 'eager';
                if (img.dataset.src) img.src = img.dataset.src;
            });
        });

});

window.forceRevealAll = function() {
  // Matikan AOS animation, langsung tampilkan semua elemen data-aos
  document.querySelectorAll('[data-aos]').forEach(el => {
    el.classList.add('aos-animate');
    el.removeAttribute('data-aos'); // supaya AOS tidak reset ulang ke hidden
  });
  if (typeof AOS !== 'undefined') {
    AOS.init({ disable: true });
  }

  // Paksa semua elemen reveal custom langsung ke kondisi visible
  document.querySelectorAll('.reveal, .reveal-card, .reveal-left, .reveal-right, .product-card, .article-side-card, .article-featured, .activity-card, .section-header')
    .forEach(el => {
      el.classList.add('active');
      el.style.opacity = '1';
      el.style.transform = 'none';
      el.style.transition = 'none';
    });

  // Matikan navbar hide-on-scroll juga sekalian
  window.__disableNavbarHide = true;
  const navbar = document.querySelector('.navbar');
  if (navbar) navbar.style.transform = 'none';
};