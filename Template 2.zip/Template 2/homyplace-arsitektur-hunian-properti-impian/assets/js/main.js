/**
 * HOMYPLACE — CYANOTYPE BLUEPRINT INTERACTIVE SCRIPT
 * Vanilla JS (No External Libraries)
 */

document.addEventListener('DOMContentLoaded', () => {
  initCustomCursor();
  initBlueprintRevealObserver();
  initScrollspy();
  initAboutSlider();
  initProductFilter();
  initCarousel();
  initFloorPlanNav();
  initMobileMenu();
  initFormInteractions();
  initNavbarDropdowns();
  initLanguageSwitcher();
});

/* ==========================================================================
   PRODUK SECTION: HORIZONTAL SNAP-SCROLL CAROUSEL & HINT INDICATOR
   ========================================================================== */
function initCarousel() {
  const track = document.getElementById('productsGrid');
  const prevBtn = document.getElementById('prevBtn');
  const nextBtn = document.getElementById('nextBtn');
  const dotsContainer = document.getElementById('carouselDots');
  const swipeHint = document.getElementById('swipeHint');

  if (!track) return;
  const cards = track.querySelectorAll('.property-card');
  const cardCount = cards.length;
  if (cardCount === 0) return;

  // Create Dot Indicators dynamically if container exists
  if (dotsContainer && dotsContainer.children.length === 0) {
    for (let i = 0; i < cardCount; i++) {
      const dot = document.createElement('div');
      dot.classList.add('dot');
      if (i === 0) dot.classList.add('active');
      dot.addEventListener('click', () => scrollToCard(i));
      dotsContainer.appendChild(dot);
    }
  }

  const dots = dotsContainer ? dotsContainer.querySelectorAll('.dot') : [];

  function scrollToCard(index) {
    const firstCard = track.querySelector('.property-card');
    if (!firstCard) return;
    const cardWidth = firstCard.offsetWidth + 28;
    track.scrollTo({
      left: cardWidth * index,
      behavior: 'smooth'
    });
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      const firstCard = track.querySelector('.property-card');
      if (!firstCard) return;
      const cardWidth = firstCard.offsetWidth + 28;
      track.scrollBy({ left: -cardWidth, behavior: 'smooth' });
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      const firstCard = track.querySelector('.property-card');
      if (!firstCard) return;
      const cardWidth = firstCard.offsetWidth + 28;
      track.scrollBy({ left: cardWidth, behavior: 'smooth' });
    });
  }

  function handleScrollUpdate() {
    const firstCard = track.querySelector('.property-card');
    if (!firstCard) return;
    const cardWidth = firstCard.offsetWidth + 28;
    const activeIndex = Math.round(track.scrollLeft / cardWidth);

    if (track.scrollLeft > 20) {
      if (swipeHint) swipeHint.classList.add('is-hidden');
    }

    if (dots.length > 0) {
      dots.forEach((dot, idx) => {
        if (idx === Math.min(activeIndex, cardCount - 1)) {
          dot.classList.add('active');
        } else {
          dot.classList.remove('active');
        }
      });
    }
  }

  track.addEventListener('scroll', handleScrollUpdate, { passive: true });

  // Mouse Drag Support
  let isDragging = false;
  let startX, scrollLeftStart;

  track.addEventListener('mousedown', (e) => {
    isDragging = true;
    track.classList.add('is-dragging');
    startX = e.pageX - track.offsetLeft;
    scrollLeftStart = track.scrollLeft;
  });

  track.addEventListener('mouseleave', () => {
    if (!isDragging) return;
    isDragging = false;
    track.classList.remove('is-dragging');
  });

  track.addEventListener('mouseup', () => {
    if (!isDragging) return;
    isDragging = false;
    track.classList.remove('is-dragging');
  });

  track.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.pageX - track.offsetLeft;
    const walk = (x - startX) * 1.5;
    track.scrollLeft = scrollLeftStart - walk;
  });
}

function initFloorPlanNav() {
  const fpTrack = document.getElementById('floorplanTrack');
  if (!fpTrack || fpTrack.children.length > 0) return;

  const roomNames = [
    'BERANDA', 'TENTANG', 'AKTIVITAS', 'PRODUK', 'ARTIKEL', 'KONTAK',
    'LOBBY', 'FOYER', 'LIVING', 'DINING', 'KITCHEN', 'PATIO',
    'TERRACE', 'GARDEN', 'POOL', 'STUDIO', 'LIBRARY', 'OFFICE',
    'BALCONY', 'LOUNGE'
  ];

  for (let i = 1; i <= 20; i++) {
    const numStr = String(i).padStart(2, '0');
    const label = roomNames[i - 1] || 'ROOM';

    const node = document.createElement('div');
    node.className = `fp-node ${i === 4 ? 'active' : ''}`;
    node.innerHTML = `
      <span class="fp-num">${numStr}</span>
      <span class="fp-label">${label}</span>
    `;

    node.addEventListener('click', () => {
      document.querySelectorAll('.fp-node').forEach(n => n.classList.remove('active'));
      node.classList.add('active');
    });

    fpTrack.appendChild(node);
  }
}

/* ==========================================================================
   1. CUSTOM CROSSHAIR CURSOR WITH REALTIME COORDINATES
   ========================================================================== */
function initCustomCursor() {
  const cursor = document.getElementById('customCursor');
  const coords = document.getElementById('cursorCoords');

  // Check if device supports hover & fine pointing (desktop) and motion is not reduced
  const isDesktop = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const isReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (!isDesktop || isReducedMotion || !cursor || !coords) return;

  cursor.style.display = 'block';

  document.addEventListener('mousemove', (e) => {
    cursor.style.left = `${e.clientX}px`;
    cursor.style.top = `${e.clientY}px`;

    // Format coordinates with padding
    const posX = String(e.clientX).padStart(4, '0');
    const posY = String(e.clientY).padStart(4, '0');
    coords.textContent = `X:${posX} Y:${posY}`;
  });
}

/* ==========================================================================
   2. BLUEPRINT REVEAL ON SCROLL (INTERSECTION OBSERVER)
   ========================================================================== */
function initBlueprintRevealObserver() {
  const sections = document.querySelectorAll('.bp-section');
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (prefersReduced) {
    sections.forEach(sec => sec.classList.add('is-revealed'));
    triggerCountUp();
    return;
  }

  let statsTriggered = false;

  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-revealed');

        // Trigger stats count up if about section is revealed
        if (entry.target.id === 'tentang' && !statsTriggered) {
          triggerCountUp();
          statsTriggered = true;
        }

        // Once revealed, unobserve if desired (or keep for subtle effect)
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.15,
    rootMargin: '0px 0px -50px 0px'
  });

  sections.forEach(sec => revealObserver.observe(sec));
}

/* ==========================================================================
   3. SCROLLSPY (MAIN NAV & FLOOR PLAN MINI-MAP HIGHLIGHT)
   ========================================================================== */
function initScrollspy() {
  const sections = document.querySelectorAll('section[id]');
  const mainNavLinks = document.querySelectorAll('.nav-link');
  const fpRooms = document.querySelectorAll('.fp-room');

  const spyObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');

        // Update Main Header Nav
        mainNavLinks.forEach(link => {
          if (link.getAttribute('data-section') === id) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });

        // Update Side Floor Plan Nav
        fpRooms.forEach(room => {
          if (room.getAttribute('data-section') === id) {
            room.classList.add('active');
          } else {
            room.classList.remove('active');
          }
        });
      }
    });
  }, {
    threshold: 0.35
  });

  sections.forEach(sec => spyObserver.observe(sec));
}

/* ==========================================================================
   4. TENTANG SECTION: BLUEPRINT TO BUILT SLIDER
   ========================================================================== */
function initAboutSlider() {
  const container = document.getElementById('revealContainer');
  const blueprintLayer = document.getElementById('blueprintLayer');
  const sliderBar = document.getElementById('revealSlider');

  if (!container || !blueprintLayer || !sliderBar) return;

  let isDragging = false;

  const updateSliderPosition = (clientX) => {
    const rect = container.getBoundingClientRect();
    let x = clientX - rect.left;

    // Clamp values between 0 and rect.width
    if (x < 0) x = 0;
    if (x > rect.width) x = rect.width;

    const percentage = (x / rect.width) * 100;
    blueprintLayer.style.width = `${percentage}%`;
    sliderBar.style.left = `${percentage}%`;
  };

  container.addEventListener('mousedown', (e) => {
    isDragging = true;
    updateSliderPosition(e.clientX);
  });

  window.addEventListener('mouseup', () => { isDragging = false; });

  container.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    updateSliderPosition(e.clientX);
  });

  // Touch Events for Mobile
  container.addEventListener('touchstart', (e) => {
    isDragging = true;
    updateSliderPosition(e.touches[0].clientX);
  }, { passive: true });

  window.addEventListener('touchend', () => { isDragging = false; });

  container.addEventListener('touchmove', (e) => {
    if (!isDragging) return;
    updateSliderPosition(e.touches[0].clientX);
  }, { passive: true });
}

/* ==========================================================================
   5. COUNT-UP ANIMATION FOR STATISTICS
   ========================================================================== */
function triggerCountUp() {
  const statNumbers = document.querySelectorAll('.stat-num');

  statNumbers.forEach(numEl => {
    const target = parseInt(numEl.getAttribute('data-target'), 10);
    const suffix = numEl.getAttribute('data-suffix') || '';
    const duration = 2000; // ms
    const stepTime = 30;
    const steps = duration / stepTime;
    const increment = target / steps;

    let current = 0;

    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        current = target;
        numEl.textContent = `${Math.round(current)}${suffix}`;
        clearInterval(timer);
      } else {
        numEl.textContent = `${Math.round(current)}${suffix}`;
      }
    }, stepTime);
  });
}

/* ==========================================================================
   6. PRODUK SECTION: FILTER CHIPS & ANIMATION
   ========================================================================== */
function initProductFilter() {
  const chips = document.querySelectorAll('.chip');
  const cards = document.querySelectorAll('.property-card');

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');

      const filterVal = chip.getAttribute('data-filter');

      cards.forEach(card => {
        const category = card.getAttribute('data-category');

        if (filterVal === 'all' || category === filterVal) {
          card.classList.remove('is-hidden');
        } else {
          card.classList.add('is-hidden');
        }
      });
    });
  });

  initProductGalleryScroll();
}

/**
 * PRODUK SECTION: VERTICAL IMAGE GALLERY SCROLL & HINT FADE-OUT
 */
function initProductGalleryScroll() {
  const imageFrames = document.querySelectorAll('.product-image-frame');

  imageFrames.forEach(frame => {
    const scrollContainer = frame.querySelector('.product-image-scroll');
    const scrollHint = frame.querySelector('.product-image-scroll-hint');
    if (!scrollContainer) return;

    const items = scrollContainer.querySelectorAll('.product-image-item');

    // If only 1 image or less, hide scroll hint
    if (items.length <= 1) {
      if (scrollHint) scrollHint.classList.add('is-hidden');
      return;
    }

    // On vertical scroll inside frame, fade out the SCROLL hint indicator
    const handleScroll = () => {
      if (scrollContainer.scrollTop > 8) {
        if (scrollHint) scrollHint.classList.add('is-hidden');
      }
    };

    scrollContainer.addEventListener('scroll', handleScroll, { passive: true });
  });
}

/* ==========================================================================
   7. MOBILE NAVIGATION MENU
   ========================================================================== */
function initMobileMenu() {
  const toggleBtn = document.getElementById('mobileToggle');
  const navMenu = document.querySelector('.main-nav');

  if (!toggleBtn || !navMenu) return;

  toggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    const isOpen = navMenu.classList.contains('is-open');
    if (isOpen) {
      closeMobileMenu();
    } else {
      openMobileMenu();
    }
  });

  // Close menu when clicking nav links (excluding dropdown triggers)
  const navLinks = navMenu.querySelectorAll('a:not(.nav-dropdown-trigger)');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      closeMobileMenu();
    });
  });

  // Close menu when clicking outside
  document.addEventListener('click', (e) => {
    if (!navMenu.contains(e.target) && !toggleBtn.contains(e.target)) {
      closeMobileMenu();
    }
  });

  // Close menu on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeMobileMenu();
    }
  });

  function openMobileMenu() {
    navMenu.classList.add('is-open');
    toggleBtn.classList.add('is-open');
    toggleBtn.setAttribute('aria-expanded', 'true');
  }

  function closeMobileMenu() {
    navMenu.classList.remove('is-open');
    toggleBtn.classList.remove('is-open');
    toggleBtn.setAttribute('aria-expanded', 'false');
  }
}

/* ==========================================================================
   8. FORM INTERACTION & SUCCESS NOTIFICATION
   ========================================================================== */
function initFormInteractions() {
  const form = document.getElementById('contactForm');
  if (!form) return;
}

function showFormSuccess() {
  const notif = document.getElementById('formNotification');
  const form = document.getElementById('contactForm');

  if (notif && form) {
    notif.className = 'form-notification success';
    notif.innerHTML = `
      <strong>[ STATUS: TERKIRIM // SPEC-OK ]</strong><br>
      Terima kasih. Rincian konsultasi Anda telah tersimpan ke dalam database studio HomyPlace. Tim arsitek kami akan menghubungi Anda dalam waktu 1x24 jam.
    `;
    form.reset();
  }
}

/* ==========================================================================
   9. NAVBAR SUBMENU DROPDOWNS
   ========================================================================== */
function initNavbarDropdowns() {
  const dropdownItems = document.querySelectorAll('.nav-item.has-dropdown');

  dropdownItems.forEach(item => {
    const trigger = item.querySelector('.nav-dropdown-trigger');
    const menu = item.querySelector('.nav-dropdown-menu');
    if (!trigger || !menu) return;

    // Hover open/close handlers (opens dropdown on cursor hover)
    item.addEventListener('mouseenter', () => {
      item.classList.add('is-open');
      trigger.setAttribute('aria-expanded', 'true');
    });

    item.addEventListener('mouseleave', () => {
      item.classList.remove('is-open');
      trigger.setAttribute('aria-expanded', 'false');
    });

    // Toggle dropdown on trigger click / tap (works for mobile touch)
    trigger.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = item.classList.contains('is-open');

      // Collapse other navbar submenus
      dropdownItems.forEach(other => {
        if (other !== item) {
          other.classList.remove('is-open');
          const t = other.querySelector('.nav-dropdown-trigger');
          if (t) t.setAttribute('aria-expanded', 'false');
        }
      });

      if (!isOpen) {
        item.classList.add('is-open');
        trigger.setAttribute('aria-expanded', 'true');
      } else {
        item.classList.remove('is-open');
        trigger.setAttribute('aria-expanded', 'false');
      }
    });

    // Submenu links click listener
    const links = menu.querySelectorAll('a');
    links.forEach(link => {
      link.addEventListener('click', () => {
        // Close navbar submenus & mobile menu on navigation
        dropdownItems.forEach(d => {
          d.classList.remove('is-open');
          const t = d.querySelector('.nav-dropdown-trigger');
          if (t) t.setAttribute('aria-expanded', 'false');
        });

        const navMenu = document.querySelector('.main-nav');
        const toggleBtn = document.getElementById('mobileToggle');
        if (navMenu) navMenu.classList.remove('is-open');
        if (toggleBtn) {
          toggleBtn.classList.remove('is-open');
          toggleBtn.setAttribute('aria-expanded', 'false');
        }
      });
    });
  });

  // Close navbar submenus on outside click
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.nav-item.has-dropdown')) {
      dropdownItems.forEach(item => {
        item.classList.remove('is-open');
        const trigger = item.querySelector('.nav-dropdown-trigger');
        if (trigger) trigger.setAttribute('aria-expanded', 'false');
      });
    }
  });

  // Escape key closes navbar submenus
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      dropdownItems.forEach(item => {
        item.classList.remove('is-open');
        const trigger = item.querySelector('.nav-dropdown-trigger');
        if (trigger) trigger.setAttribute('aria-expanded', 'false');
      });
    }
  });
}

/* ==========================================================================
   10. I18N BILINGUAL TRANSLATION SYSTEM (ID / EN)
   ========================================================================== */
const translations = {
  id: {
    // Navigation & Floor plan
    "nav.beranda": "Beranda",
    "nav.tentang": "Tentang",
    "nav.aktivitas": "Aktivitas",
    "nav.produk": "Produk",
    "nav.artikel": "Artikel",
    "nav.kontak": "Kontak",
    "nav.sub.semua_aktivitas": "Semua Aktivitas",
    "nav.sub.survey_lahan": "Survey Lahan",
    "nav.sub.desain_blueprint": "Desain Blueprint",
    "nav.sub.konstruksi": "Konstruksi",
    "nav.sub.perizinan": "Perizinan",
    "nav.sub.serah_terima": "Serah Terima",
    "nav.sub.semua_artikel": "Semua Artikel",
    "nav.sub.tips_arsitektur": "Tips Arsitektur",
    "nav.sub.estetika_material": "Estetika Material",
    "nav.sub.berita_pasar": "Berita Pasar",
    "nav.sub.panduan_legal": "Panduan Legal",
    "fp.beranda": "BERANDA",
    "fp.tentang": "TENTANG",
    "fp.aktivitas": "AKTIVITAS",
    "fp.produk": "PRODUK",
    "fp.artikel": "ARTIKEL",
    "fp.kontak": "KONTAK",

    // Hero Section
    "hero.heading_part1": "Dari Cetak Biru Presisi,",
    "hero.heading_part2": "Menjadi",
    "hero.heading_accent": "Hunian Impian",
    "hero.heading_part3": "Nyata.",
    "hero.subtext": "HomyPlace memadukan estetika arsitektur cetak biru dengan kehangatan ruang keluarga. Kami merancang, membangun, dan menyajikan rumah bernilai seni tinggi dengan kepastian struktur & fungsi.",

    // Tentang Section
    "about.label": "[02] PROFIL & VISI PERUSAHAAN",
    "about.title": "Mengubah Garis Cetak Biru Menjadi Ruang Kehidupan",
    "about.lead": "Di HomyPlace, kami mempercayai bahwa rumah bukanlah sekadar tumpukan bata dan semen. Rumah adalah manifestasi dari perhitungan presisi, harmoni material, dan kenyamanan penghuninya.",
    "about.p1": "Berdiri sejak tahun 2011, HomyPlace menggabungkan studio arsitektur terpadu dengan pengembangan properti terpercaya. Setiap denah dipikirkan secara mendalam: mengoptimalkan sirkulasi udara alami, pencahayaan matahari, hingga efisiensi struktur jangka panjang.",
    "about.badge_slide": "SCROLL / SLIDE DARI DRAFT KE WUJUD NYATA",
    "about.state_built": "STATE 02: REALITAS TERBANGUN",
    "about.state_blueprint": "STATE 01: BLUEPRINT DRAFT",
    "about.caption_prefix": "ANOTASI:",
    "about.caption_text": "Geser bilah untuk melihat perbandingan blueprint rancangan vs hasil akhir fisik rumah.",

    // Aktivitas Section
    "aktivitas.label": "[03] PROSES & AKTIVITAS RANCANG",
    "aktivitas.title": "Tahapan Presisi Pembangunan",
    "aktivitas.desc": "Bagaimana kami mengawal proyek Anda dari sketsa awal hingga penyerahan kunci dengan disiplin arsitektur ketat.",
    "aktivitas.step1_title": "1. Survei Lahan & Kontur Topografi",
    "aktivitas.step1_desc": "Analisis mendalam terhadap pencahayaan matahari, arah angin, daya dukung tanah, serta kontur tapak sebelum membuat satu garis garis pun.",
    "aktivitas.step2_title": "2. Pembuatan Blueprint & Skema 3D",
    "aktivitas.step2_desc": "Penyusunan denah, tampak, potongan, skema utilitas ME, hingga maket 3D interaktif agar klien memahami alur fungsi seluruh ruang.",
    "aktivitas.step3_title": "3. Konstruksi & Quality Assurance",
    "aktivitas.step3_desc": "Pengerjaan fisik oleh tim ahli dengan laporan berkala mingguan. Pengawasan ketat memastikan dimensi fisik presisi sesuai gambar kerja.",
    "aktivitas.step4_title": "4. Perizinan & Legalitas PBG",
    "aktivitas.step4_desc": "Pengurusan Izin Mendirikan Bangunan (PBG/IMB) dan sertifikat kelayakan fungsi struktur secara resmi dan tepat waktu.",
    "aktivitas.btn_more": "LIHAT SELENGKAPNYA",

    // Produk Section
    "produk.label": "[04] KATALOG PROPERTI EXCLUSIVE",
    "produk.title": "Koleksi Hunian Arsitektural HomyPlace",
    "produk.desc": "Temukan properti idaman dengan rincian teknis transparan dan standar estetika tinggi.",
    "produk.filter_label": "FILTER TIPE:",
    "produk.filter_all": "SEMUA PROPERTI [6]",
    "produk.filter_minimalis": "RUMAH MINIMALIS",
    "produk.filter_villa": "VILLA MODERN",
    "produk.filter_cluster": "CLUSTER EXCLUSIVE",
    "produk.filter_commercial": "RUKO / COMMERCIAL",
    "produk.btn_detail": "DETAIL →",

    // Artikel Section
    "artikel.label": "[05] Wawasan Arsitektur & Properti",
    "artikel.title": "Jurnal & Panduan Cetak Biru",
    "artikel.feat_tag": "DESAIN & STRUKTUR",
    "artikel.feat_read": "WAKTU BACA: 6 MENIT",
    "artikel.feat_title": "Bagaimana Menghitung Sinar Matahari Tropis Sebelum Menggambar Pondasi Rumah",
    "artikel.feat_excerpt": "Pencahayaan alami bukan sekadar memasang jendela besar. Penataan sudut fasad berpatokan koordinat matahari dapat menurunkan konsumsi listrik AC hingga 35% per tahun. Simak rumus orientasi ruang dari studio kami.",
    "artikel.feat_by": "Oleh: Ir. Baskoro Hadiputra, IAI",
    "artikel.read_more": "BACA SELENGKAPNYA →",
    "artikel.sub1_cat": "ESTETIKA MATERIAL",
    "artikel.sub1_title": "Mengapa Kami Memilih Beton Ekspos & Kayu Jati Daur Ulang dalam Setiap Cetak Biru",
    "artikel.sub1_desc": "Perpaduan tekstur dingin beton presisi dengan kehangatan serat kayu alami menciptakan karakter rumah tahan zaman.",
    "artikel.sub2_cat": "PANDUAN LEGAL",
    "artikel.sub2_title": "Checklist 10 Poin Legalitas & Struktur Sebelum Membeli Rumah Off-Plan",
    "artikel.sub2_desc": "Jangan hanya tergiur brosur render 3D. Pastikan dokumen cetak biru IMB/PBG & kelayakan uji tanah sudah tervalidasi.",
    "artikel.sub3_cat": "TIPS ARSITEKTUR",
    "artikel.sub3_title": "Optimalisasi Lahan Sempit 90m² Menjadi Split-Level 3 Lantai yang Lapang",
    "artikel.sub3_desc": "Trik permainan mezanin dan void tangga tengah untuk sirkulasi udara optimal di kawasan perkotaan padat.",
    "artikel.sub4_cat": "BERITA PASAR",
    "artikel.sub4_title": "Analisis Tren Nilai Properti Koridor BSD-Bintaro Semester II 2026",
    "artikel.sub4_desc": "Proyeksi kenaikan capital gain hunian berkonsep arsitektur hijau pasca perluasan jaringan jalan tol lingkar luar.",

    // Kontak Section
    "contact.tag": "06 / KONTAK",
    "contact.title": "Mari Bicara <br>Tentang Properti Anda",
    "contact.desc": "Punya pertanyaan seputar properti, ingin konsultasi desain, atau menjadwalkan survey lahan? Tim kami siap membantu.",
    "contact.addressLabel": "ALAMAT KANTOR",
    "contact.addressDetail": "Jl. Danau Amora No.C5 E8, Sawojajar 1, Kota Malang",
    "contact.phoneLabel": "TELEPON // LINE UTAMA",
    "contact.phoneDetail": "+62 21 5557 8900 / +62 811 9900 8877",
    "contact.emailLabel": "ELECTRONIC MAIL",
    "contact.emailDetail": "blueprint@homyplace.co.id",
    "contact.hoursLabel": "JAM OPERASIONAL",
    "contact.hoursDetail": "SENIN - SABTU // 08:30 - 17:30 WIB",
    "kontak.label": "[06] HUBUNGI STUDIO KAMI",
    "kontak.title": "Mulai Diskusi Cetak Biru Rumah Anda",
    "kontak.desc": "Kunjungi studio kami atau kirimkan rincian kebutuhan lahan Anda. Tim tim arsitek HomyPlace siap menyusun sketsa awal gratis.",
    "kontak.studio_label": "STUDIO UTAMA // JAKARTA",
    "kontak.phone_label": "TELEPON // LINE UTAMA",
    "kontak.email_label": "ELECTRONIC MAIL",
    "kontak.hours_label": "JAM OPERASIONAL",
    "kontak.hours_val": "SENIN - SABTU // 08:30 - 17:30 WIB",
    "kontak.form_title": "FORM KONSULTASI ARSITEKTUR // FORM-REV.03",
    "kontak.name_label": "NAMA LENGKAP KLIEN *",
    "kontak.name_placeholder": "misal: Budi Santoso",
    "kontak.email_label_form": "ALAMAT EMAIL *",
    "kontak.email_placeholder": "nama@domain.com",
    "kontak.phone_label_form": "NOMOR TELEPON / WA *",
    "kontak.phone_placeholder": "0812xxxxxxxx",
    "kontak.category_label": "KATEGORI KETERTARIKAN",
    "kontak.cat_minimalis": "Rumah Minimalis Modern",
    "kontak.cat_villa": "Villa Private Estate",
    "kontak.cat_custom": "Desain Custom dari Nol (Bespoke)",
    "kontak.cat_renovation": "Renovasi & Redesain Struktur",
    "kontak.budget_label": "ESTIMASI ANGGARAN",
    "kontak.budget_opt1": "Rp 1 Miliar — 2 Miliar",
    "kontak.budget_opt2": "Rp 2 Miliar — 4 Miliar",
    "kontak.budget_opt3": "> Rp 4 Miliar",
    "kontak.msg_label": "DESKRIPSI KEBUTUHAN LAHAN & IMPIAN RUANG",
    "kontak.msg_placeholder": "Jelaskan ukuran lahan (LT/LB), jumlah kamar, atau gaya hunian yang diinginkan...",
    "kontak.btn_submit": "KIRIM RINCIAN KONSULTASI",

    // Footer
    "footer.tagline": "Mewujudkan cetak biru arsitektur presisi menjadi tempat berlindung paling hangat untuk masa depan Anda.",
    "footer.nav_header": "// NAVIGASI",
    "footer.legal_header": "// ANOTASI HUKUM",
    "footer.legal_text": "DRAWING SET: HP-2026-FINAL\nHAK CIPTA © 2026 PT HOMYPLACE CIPTA ARSITEK.\nSELURUH RANCANGAN DAN CETAK BIRU DILINDUNGI HUKUM."
  },

  en: {
    // Navigation & Floor plan
    "nav.beranda": "Home",
    "nav.tentang": "About",
    "nav.aktivitas": "Activities",
    "nav.produk": "Properties",
    "nav.artikel": "Articles",
    "nav.kontak": "Contact",
    "nav.sub.semua_aktivitas": "All Activities",
    "nav.sub.survey_lahan": "Land Survey",
    "nav.sub.desain_blueprint": "Blueprint Design",
    "nav.sub.konstruksi": "Construction",
    "nav.sub.perizinan": "Permits & Legal",
    "nav.sub.serah_terima": "Handover",
    "nav.sub.semua_artikel": "All Articles",
    "nav.sub.tips_arsitektur": "Architectural Tips",
    "nav.sub.estetika_material": "Material Aesthetics",
    "nav.sub.berita_pasar": "Market News",
    "nav.sub.panduan_legal": "Legal Guide",
    "fp.beranda": "HOME",
    "fp.tentang": "ABOUT",
    "fp.aktivitas": "ACTIVITIES",
    "fp.produk": "PROPERTIES",
    "fp.artikel": "ARTICLES",
    "fp.kontak": "CONTACT",

    // Hero Section
    "hero.heading_part1": "From Precision Blueprints,",
    "hero.heading_part2": "To Real",
    "hero.heading_accent": "Dream Homes",
    "hero.heading_part3": "Reality.",
    "hero.subtext": "HomyPlace combines blueprint architectural aesthetics with family warmth. We design, build, and present high-art houses with structural & functional certainty.",

    // Tentang Section
    "about.label": "[02] COMPANY PROFILE & VISION",
    "about.title": "Transforming Blueprint Lines Into Living Spaces",
    "about.lead": "At HomyPlace, we believe a home is not just a stack of bricks and cement. A home is a manifestation of precise calculations, material harmony, and resident comfort.",
    "about.p1": "Founded in 2011, HomyPlace combines an integrated architectural studio with trusted property development. Every layout is deeply thought out: optimizing natural ventilation, sunlight, and long-term structural efficiency.",
    "about.badge_slide": "SCROLL / SLIDE FROM DRAFT TO REALITY",
    "about.state_built": "STATE 02: BUILT REALITY",
    "about.state_blueprint": "STATE 01: BLUEPRINT DRAFT",
    "about.caption_prefix": "ANNOTATION:",
    "about.caption_text": "Slide the bar to compare blueprint design vs final physical home.",

    // Aktivitas Section
    "aktivitas.label": "[03] DESIGN PROCESS & ACTIVITIES",
    "aktivitas.title": "Precision Stages of Building",
    "aktivitas.desc": "How we guide your project from initial sketch to key handover with strict architectural discipline.",
    "aktivitas.step1_title": "1. Site Survey & Topographic Contour",
    "aktivitas.step1_desc": "In-depth analysis of sunlight, wind direction, soil bearing capacity, and contour before drawing a single line.",
    "aktivitas.step2_title": "2. Blueprint & 3D Schematic Drafting",
    "aktivitas.step2_desc": "Drafting floor plans, elevations, sections, ME utility schemes, and 3D models for full spatial clarity.",
    "aktivitas.step3_title": "3. Construction & Quality Assurance",
    "aktivitas.step3_desc": "Physical execution by expert teams with weekly reports. Strict supervision ensures exact blueprint dimensions.",
    "aktivitas.step4_title": "4. Permits & Legal Approval (PBG)",
    "aktivitas.step4_desc": "Official processing of Building Permits (PBG/IMB) and structural compliance certificates on schedule.",
    "aktivitas.btn_more": "VIEW DETAILS",

    // Produk Section
    "produk.label": "[04] EXCLUSIVE PROPERTY CATALOG",
    "produk.title": "HomyPlace Architectural Residence Collection",
    "produk.desc": "Discover your dream property with transparent technical details and high aesthetic standards.",
    "produk.filter_label": "FILTER TYPE:",
    "produk.filter_all": "ALL PROPERTIES [6]",
    "produk.filter_minimalis": "MINIMALIST HOMES",
    "produk.filter_villa": "MODERN VILLAS",
    "produk.filter_cluster": "EXCLUSIVE CLUSTERS",
    "produk.filter_commercial": "COMMERCIAL SHOPS",
    "produk.btn_detail": " DETAILS →",

    // Artikel Section
    "artikel.label": "[05] Architecture & Property Insights",
    "artikel.title": "Journal & Blueprint Guides",
    "artikel.feat_tag": "DESIGN & STRUCTURE",
    "artikel.feat_read": "READ TIME: 6 MINS",
    "artikel.feat_title": "How to Calculate Tropical Sunlight Before Drawing House Foundations",
    "artikel.feat_excerpt": "Natural lighting is not just about big windows. Solar facade orientation reduces AC power by up to 35% annually. Learn our spatial orientation formula.",
    "artikel.feat_by": "By: Ir. Baskoro Hadiputra, IAI",
    "artikel.read_more": "READ MORE →",
    "artikel.sub1_cat": "MATERIAL AESTHETICS",
    "artikel.sub1_title": "Why We Choose Exposed Concrete & Recycled Teak in Every Blueprint",
    "artikel.sub1_desc": "Combining cold precision concrete with warm natural wood fibers creates timeless homes.",
    "artikel.sub2_cat": "LEGAL GUIDE",
    "artikel.sub2_title": "10-Point Legal & Structural Checklist Before Buying Off-Plan Homes",
    "artikel.sub2_desc": "Don't just rely on 3D renders. Ensure blueprint IMB/PBG and soil test documents are validated.",
    "artikel.sub3_cat": "ARCHITECTURAL TIPS",
    "artikel.sub3_title": "Optimizing Narrow 90m² Plots Into Spacious 3-Story Split-Levels",
    "artikel.sub3_desc": "Mezzanine and central void tricks for optimal air circulation in dense urban areas.",
    "artikel.sub4_cat": "MARKET NEWS",
    "artikel.sub4_title": "BSD-Bintaro Corridor Property Value Trend Analysis H2 2026",
    "artikel.sub4_desc": "Capital gain projections for green architectural homes following ring road expansions.",

    // Kontak Section
    "contact.tag": "06 / CONTACT",
    "contact.title": "Let's Talk <br>About Your Property",
    "contact.desc": "Have property questions, want design consultation, or scheduling a site survey? Our team is ready to help.",
    "contact.addressLabel": "OFFICE ADDRESS",
    "contact.addressDetail": "Jl. Danau Amora No.C5 E8, Sawojajar 1, Malang City",
    "contact.phoneLabel": "PHONE // MAIN LINE",
    "contact.phoneDetail": "+62 21 5557 8900 / +62 811 9900 8877",
    "contact.emailLabel": "ELECTRONIC MAIL",
    "contact.emailDetail": "blueprint@homyplace.co.id",
    "contact.hoursLabel": "OPERATING HOURS",
    "contact.hoursDetail": "MONDAY - SATURDAY // 08:30 - 17:30 WIB",
    "kontak.label": "[06] CONTACT OUR STUDIO",
    "kontak.title": "Start Your House Blueprint Discussion",
    "kontak.desc": "Visit our studio or send your land requirements. The HomyPlace architect team is ready to draft free initial sketches.",
    "kontak.studio_label": "MAIN STUDIO // JAKARTA",
    "kontak.phone_label": "PHONE // MAIN LINE",
    "kontak.email_label": "ELECTRONIC MAIL",
    "kontak.hours_label": "OPERATING HOURS",
    "kontak.hours_val": "MONDAY - SATURDAY // 08:30 - 17:30 WIB",
    "kontak.form_title": "ARCHITECTURAL CONSULTATION FORM // FORM-REV.03",
    "kontak.name_label": "CLIENT FULL NAME *",
    "kontak.name_placeholder": "e.g. Budi Santoso",
    "kontak.email_label_form": "EMAIL ADDRESS *",
    "kontak.email_placeholder": "name@domain.com",
    "kontak.phone_label_form": "PHONE NUMBER / WHATSAPP *",
    "kontak.phone_placeholder": "+62812xxxxxxxx",
    "kontak.category_label": "INTEREST CATEGORY",
    "kontak.cat_minimalis": "Modern Minimalist House",
    "kontak.cat_villa": "Private Estate Villa",
    "kontak.cat_custom": "Bespoke Custom Design",
    "kontak.cat_renovation": "Structural Renovation & Redesign",
    "kontak.budget_label": "BUDGET ESTIMATE",
    "kontak.budget_opt1": "IDR 1 Billion — 2 Billion",
    "kontak.budget_opt2": "IDR 2 Billion — 4 Billion",
    "kontak.budget_opt3": "> IDR 4 Billion",
    "kontak.msg_label": "LAND REQUIREMENTS & DREAM SPACE DESCRIPTION",
    "kontak.msg_placeholder": "Describe land dimensions, room count, or preferred architectural style...",
    "kontak.btn_submit": "SUBMIT CONSULTATION DETAILS",

    // Footer
    "footer.tagline": "Turning precise architectural blueprints into the warmest shelter for your future.",
    "footer.nav_header": "// NAVIGATION",
    "footer.legal_header": "// LEGAL ANNOTATIONS",
    "footer.legal_text": "DRAWING SET: HP-2026-FINAL\nCOPYRIGHT © 2026 PT HOMYPLACE CIPTA ARSITEK.\nALL DESIGNS AND BLUEPRINTS PROTECTED BY LAW."
  }
};

function initLanguageSwitcher() {
  const dropdown = document.querySelector('[data-lang-dropdown]');
  const trigger = document.getElementById('langDropdownTrigger');
  const items = document.querySelectorAll('.lang-dropdown-item');

  const savedLang = localStorage.getItem('homyplace-lang') || 'id';
  applyLanguage(savedLang);

  if (!dropdown || !trigger || !items.length) return;

  // Toggle dropdown on trigger click
  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    const isOpen = dropdown.classList.contains('is-open');
    if (isOpen) {
      closeLangDropdown();
    } else {
      openLangDropdown();
    }
  });

  // Handle item click
  items.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const selectedLang = btn.getAttribute('data-lang');
      if (!selectedLang) return;
      applyLanguage(selectedLang);
      closeLangDropdown();
    });
  });

  // Close when clicking outside
  document.addEventListener('click', (e) => {
    if (!dropdown.contains(e.target)) {
      closeLangDropdown();
    }
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeLangDropdown();
    }
  });

  function openLangDropdown() {
    dropdown.classList.add('is-open');
    trigger.setAttribute('aria-expanded', 'true');
  }

  function closeLangDropdown() {
    dropdown.classList.remove('is-open');
    trigger.setAttribute('aria-expanded', 'false');
  }
}

function applyLanguage(lang) {
  if (!translations[lang]) return;

  // Set html lang attribute
  document.documentElement.setAttribute('lang', lang);

  // Store preference
  localStorage.setItem('homyplace-lang', lang);

  // Update text content for [data-i18n]
  const i18nElements = document.querySelectorAll('[data-i18n]');
  i18nElements.forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (key && translations[lang][key] !== undefined) {
      el.style.transition = 'opacity 0.15s ease';
      el.style.opacity = '0.4';
      setTimeout(() => {
        const val = translations[lang][key];
        if (val.includes('<') && val.includes('>')) {
          el.innerHTML = val;
        } else {
          el.textContent = val;
        }
        el.style.opacity = '1';
      }, 100);
    }
  });

  // Update placeholders for [data-i18n-placeholder]
  const placeholderElements = document.querySelectorAll('[data-i18n-placeholder]');
  placeholderElements.forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (key && translations[lang][key] !== undefined) {
      el.setAttribute('placeholder', translations[lang][key]);
    }
  });

  // Update active language indicator code in dropdown trigger
  const currentLangCodeEl = document.querySelector('.current-lang-code');
  if (currentLangCodeEl) {
    currentLangCodeEl.textContent = lang.toUpperCase();
  }

  // Update active state on language dropdown items
  const langItems = document.querySelectorAll('.lang-dropdown-item');
  langItems.forEach(btn => {
    const btnLang = btn.getAttribute('data-lang');
    if (btnLang === lang) {
      btn.classList.add('is-active');
      btn.setAttribute('aria-selected', 'true');
    } else {
      btn.classList.remove('is-active');
      btn.setAttribute('aria-selected', 'false');
    }
  });
}




