// ===== HAMBURGER MENU =====
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');
const navLinks = document.querySelectorAll('.nav-link');

hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    hamburger.classList.toggle('active');
});
navLinks.forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
    });
});

// ===== NAVBAR: transparan -> solid saat scroll =====
const navbar = document.getElementById('navbar');
function updateNavbar() {
    if (window.scrollY > 60) navbar.classList.add('scrolled');
    else navbar.classList.remove('scrolled');
}
window.addEventListener('scroll', updateNavbar);
updateNavbar();

// ===== ACTIVE NAV LINK ON SCROLL =====
const sections = document.querySelectorAll('section[id]');
window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 120;
        if (window.scrollY >= sectionTop) current = section.getAttribute('id');
    });
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) link.classList.add('active');
    });
});

// ===== HERO: foto latar bergantian =====
(function heroBgRotate() {
    const layers = document.querySelectorAll('.hero-bg-layer');
    if (!layers.length) return;
    let i = 0;
    setInterval(() => {
        layers[i].classList.remove('active');
        i = (i + 1) % layers.length;
        layers[i].classList.add('active');
    }, 5000);
})();

// ===== MENU: carousel geser =====
(function menuCarousel() {
    const track = document.getElementById('menuTrack');
    const prevBtn = document.getElementById('menuPrev');
    const nextBtn = document.getElementById('menuNext');
    const dotsContainer = document.getElementById('menuDots');
    if (!track || !dotsContainer) return;

    const cards = track.querySelectorAll('.menu-card');
    const scrollAmount = 336; // Card width (310) + Gap (26)

    // Generate dots dynamically
    cards.forEach((card, idx) => {
        const dot = document.createElement('button');
        dot.classList.add('carousel-dot');
        dot.setAttribute('aria-label', `Slide ${idx + 1}`);
        if (idx === 0) dot.classList.add('active');
        
        dot.addEventListener('click', () => {
            const cardOffset = card.offsetLeft - track.offsetLeft;
            track.scrollTo({
                left: cardOffset - 16,
                behavior: 'smooth'
            });
        });
        dotsContainer.appendChild(dot);
    });

    // Update dots active state on scroll
    track.addEventListener('scroll', () => {
        const scrollLeft = track.scrollLeft;
        let activeIndex = 0;
        let minDiff = Infinity;

        cards.forEach((card, idx) => {
            const cardOffset = card.offsetLeft - track.offsetLeft;
            const diff = Math.abs(cardOffset - 16 - scrollLeft);
            if (diff < minDiff) {
                minDiff = diff;
                activeIndex = idx;
            }
        });

        const dots = dotsContainer.querySelectorAll('.carousel-dot');
        dots.forEach((dot, idx) => {
            if (idx === activeIndex) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
    });

    prevBtn.addEventListener('click', () => track.scrollBy({ left: -scrollAmount, behavior: 'smooth' }));
    nextBtn.addEventListener('click', () => track.scrollBy({ left: scrollAmount, behavior: 'smooth' }));
})();

// ===== ABOUT: animasi hitung angka statistik =====
(function statCounters() {
    const counters = document.querySelectorAll('.stat-number');
    if (!counters.length) return;
    let animated = false;

    function animate() {
        if (animated) return;
        animated = true;
        counters.forEach(counter => {
            const target = parseInt(counter.getAttribute('data-count'), 10);
            let current = 0;
            const step = Math.max(1, Math.ceil(target / 40));
            const timer = setInterval(() => {
                current += step;
                if (current >= target) { current = target; clearInterval(timer); }
                counter.textContent = current;
            }, 35);
        });
    }

    const target = document.querySelector('.about-stats');
    if (target) {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => { if (entry.isIntersecting) animate(); });
        }, { threshold: 0.4 });
        observer.observe(target);
    }
})();

// ===== LANGUAGE TOGGLE (ID <-> EN) =====
const translations = {
    id: {
        nav: { home: "Beranda", about: "Tentang", product: "Menu", activity: "Aktivitas", article: "Artikel", contact: "Kontak" },
        hero: {
            eyebrow: "SEJAK 2018 · KEDAI KOPI SPECIALTY",
            title: "Nikmatnya <span class=\"highlight\">Kopi</span>,<br>Hangatnya Cerita",
            subtitle: "Diseduh dari biji kopi Nusantara pilihan, disajikan dengan hati setiap hari.",
            btnMenu: "Lihat Menu", btnAbout: "Kenali Kami", scroll: "SCROLL"
        },
        about: {
            tag: "TENTANG KAMI",
            heading: "Kopi specialty dari biji pilihan, diseduh dengan hati",
            paragraph: "Coffee House lahir dari kecintaan pada kopi Nusantara. Kami menyangrai sendiri biji kopi dari petani lokal, tanpa campuran, dan menyeduhnya segar setiap hari — dari manual brew yang lembut hingga espresso yang pekat.",
            badgeTitle: "100% Biji Lokal", badgeSub: "Dari petani Nusantara",
            stat1: "Tahun Pengalaman", stat2: "Varian Biji Kopi", stat3: "Pelanggan Puas",
            button: "Jelajahi Menu Kami"
        },
        product: {
            tag: "MENU FAVORIT", heading: "Racikan yang Paling Dicari",
            item1: "Signature drink kami — espresso pekat, susu segar, dan gula aren asli yang manisnya pas.",
            item2: "Perpaduan espresso, susu steam, dan foam lembut dengan latte art di atasnya.",
            item3: "Pastry klasik Prancis, renyah di luar dan lembut di dalam, dipanggang segar tiap pagi.",
            item4: "Single origin pilihan dari daerah penghasil kopi terbaik Indonesia, disangrai sendiri.",
            item5: "Potongan kue lembut dengan rasa creamy pas, teman sempurna secangkir kopi."
        },
        activity: {
            tag: "AKTIVITAS", heading: "Jelajahi Aktivitas Kami",
            item1: { title: "Workshop Manual Brew", text: "Pelajari seni menyeduh kopi manual dari awal hingga siap saji — grinding, pouring, hingga rasio air dan kopi yang pas." },
            item2: { title: "Kelas Latte Art", text: "Belajar membuat pola foam yang cantik di atas kopi, dari heart sederhana hingga rosetta yang lebih rumit." },
            item3: { title: "Konsultasi Racikan Kopi", text: "Tim barista kami siap memberi rekomendasi biji kopi dan metode seduh terbaik sesuai selera Anda." }
        },
        article: {
            tag: "ARTIKEL", readMore: "BACA SELENGKAPNYA", heading: "Cerita & Inspirasi Kopi",
            item1: { category: "Tips", title: "Tips Menyimpan Biji Kopi agar Aromanya Tetap Terjaga" },
            item2: { category: "Inspirasi", title: "Inspirasi Menu Kopi Kekinian untuk Cafehopping" },
            item3: { category: "Rekomendasi", title: "Rahasia Membuat Cold Brew Nikmat di Rumah" }
        },
        contact: { tag: "KONTAK", heading: "Datang & Ngopi Bareng Kami" },
        footer: {
            linksTitle: "Tautan", followTitle: "Ikuti Kami :", articleTitle: "Artikel Kami", marketTitle: "Marketplace Kami",
            copy: "\u00A9 2026 Setiap Cangkir Punya Cerita. Hak Cipta Dilindungi."
        }
    },
    en: {
        nav: { home: "Home", about: "About", product: "Menu", activity: "Activities", article: "Articles", contact: "Contact" },
        hero: {
            eyebrow: "SINCE 2018 · SPECIALTY COFFEE SHOP",
            title: "The Warmth of <span class=\"highlight\">Coffee</span>,<br>The Warmth of Stories",
            subtitle: "Brewed from selected Indonesian coffee beans, served with love every day.",
            btnMenu: "View Menu", btnAbout: "Know Us", scroll: "SCROLL"
        },
        about: {
            tag: "ABOUT US",
            heading: "Specialty coffee from selected beans, brewed with love",
            paragraph: "Coffee House was born from a love of Indonesian coffee. We roast our own beans from local farmers, with no blends, brewed fresh every day — from smooth manual brew to bold espresso.",
            badgeTitle: "100% Local Beans", badgeSub: "From Indonesian farmers",
            stat1: "Years of Experience", stat2: "Coffee Bean Varieties", stat3: "Happy Customers",
            button: "Explore Our Menu"
        },
        product: {
            tag: "FAVORITE MENU", heading: "Our Most Sought-After Brews",
            item1: "Our signature drink — bold espresso, fresh milk, and authentic palm sugar with just the right sweetness.",
            item2: "A blend of espresso, steamed milk, and smooth foam topped with latte art.",
            item3: "A classic French pastry, crisp outside and soft inside, baked fresh every morning.",
            item4: "Selected single-origin beans from Indonesia's finest coffee regions, roasted in-house.",
            item5: "A soft, perfectly creamy slice of cake, the ideal companion to your coffee."
        },
        activity: {
            tag: "ACTIVITY", heading: "Explore Our Activities",
            item1: { title: "Manual Brew Workshop", text: "Learn the art of manual coffee brewing from start to finish — grinding, pouring, and the right water-to-coffee ratio." },
            item2: { title: "Latte Art Class", text: "Learn to create beautiful foam patterns on your coffee, from a simple heart to an intricate rosetta." },
            item3: { title: "Coffee Menu Consultation", text: "Our barista team is ready to recommend the best beans and brewing method for your taste." }
        },
        article: {
            tag: "ARTICLE", readMore: "READ MORE", heading: "Coffee Stories & Inspiration",
            item1: { category: "Tips", title: "Tips for Keeping Coffee Beans Fresh and Aromatic" },
            item2: { category: "Inspiration", title: "Trendy Coffee Menu Inspiration for Cafehopping" },
            item3: { category: "Recommendation", title: "The Secret to Making Delicious Cold Brew at Home" }
        },
        contact: { tag: "CONTACT", heading: "Come & Have Coffee With Us" },
        footer: {
            linksTitle: "Links", followTitle: "Follow Us:", articleTitle: "Our Articles", marketTitle: "Our Marketplace",
            copy: "\u00A9 2026 Every Cup Tells a Story. All Rights Reserved."
        }
    }
};

(function languageToggle() {
    const langBtn = document.getElementById('langToggle');
    const langLabel = document.getElementById('langToggleLabel');
    if (!langBtn) return;

    function getByPath(obj, path) {
        return path.split('.').reduce((acc, key) => (acc && acc[key] !== undefined) ? acc[key] : null, obj);
    }
    function applyLanguage(lang) {
        const dict = translations[lang];
        if (!dict) return;
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const value = getByPath(dict, el.getAttribute('data-i18n'));
            if (typeof value === 'string') el.textContent = value;
        });
        document.querySelectorAll('[data-i18n-html]').forEach(el => {
            const value = getByPath(dict, el.getAttribute('data-i18n-html'));
            if (typeof value === 'string') el.innerHTML = value;
        });
        document.documentElement.setAttribute('lang', lang);
        langLabel.textContent = lang.toUpperCase();
        try { localStorage.setItem('coffeehouse-lang', lang); } catch (e) { }
    }

    let currentLang = 'id';
    try { currentLang = localStorage.getItem('coffeehouse-lang') || 'id'; } catch (e) { }
    applyLanguage(currentLang);

    langBtn.addEventListener('click', () => {
        currentLang = currentLang === 'id' ? 'en' : 'id';
        applyLanguage(currentLang);
    });
})();