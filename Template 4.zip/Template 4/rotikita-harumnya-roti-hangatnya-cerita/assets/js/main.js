// ===== HAMBURGER MENU =====

const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');
const navLinks = document.querySelectorAll('.nav-link');

hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    hamburger.classList.toggle('active');
});

navLinks.forEach(link => {
    link.addEventListener('click', () => {
        // don't close the mobile menu when just opening a dropdown toggle
        if (link.classList.contains('dropdown-toggle')) return;
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
    });
});

// close mobile menu after picking a dropdown item
document.querySelectorAll('.dropdown-menu a').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
        document.querySelectorAll('.nav-item.dropdown.open').forEach(el => el.classList.remove('open'));
    });
});

// ===== ACTIVE NAV LINK ON SCROLL =====
const sections = document.querySelectorAll('section[id]');
window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        if (window.scrollY >= sectionTop) {
            current = section.getAttribute('id');
        }
    });
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// ===== NAVBAR DROPDOWN (Activitas & Artikel) =====
// Desktop: CSS :hover handles opening/closing.
// Mobile/touch: tapping the dropdown label toggles the submenu instead of
// navigating away, since there's no hover state on touch devices.
document.querySelectorAll('.nav-item.dropdown > .dropdown-toggle').forEach(toggle => {
    toggle.addEventListener('click', (e) => {
        const isMobile = window.matchMedia('(max-width: 768px)').matches;
        if (!isMobile) return; // let the link behave normally on desktop
        e.preventDefault();
        const parent = toggle.closest('.nav-item.dropdown');
        const wasOpen = parent.classList.contains('open');
        document.querySelectorAll('.nav-item.dropdown.open').forEach(el => el.classList.remove('open'));
        if (!wasOpen) parent.classList.add('open');
    });
});

// ===== HERO SLIDER (image + text change together) =====
(function heroSlider() {
    const slider = document.getElementById('heroSlider');
    if (!slider) return;
    const slides = slider.querySelectorAll('.hero-slide');
    const dots = slider.querySelectorAll('.hero-dot');
    const prevBtn = document.getElementById('heroPrev');
    const nextBtn = document.getElementById('heroNext');
    let current = 0;
    let timer = null;
    const AUTOPLAY_MS = 6000;

    function goTo(index) {
        current = (index + slides.length) % slides.length;
        slides.forEach((slide, i) => slide.classList.toggle('active', i === current));
        dots.forEach((dot, i) => dot.classList.toggle('active', i === current));
    }

    function next() { goTo(current + 1); }
    function prev() { goTo(current - 1); }

    function startAutoplay() {
        stopAutoplay();
        timer = setInterval(next, AUTOPLAY_MS);
    }
    function stopAutoplay() {
        if (timer) clearInterval(timer);
    }

    dots.forEach((dot, i) => {
        dot.addEventListener('click', () => { goTo(i); startAutoplay(); });
    });
    if (nextBtn) nextBtn.addEventListener('click', () => { next(); startAutoplay(); });
    if (prevBtn) prevBtn.addEventListener('click', () => { prev(); startAutoplay(); });

    slider.addEventListener('mouseenter', stopAutoplay);
    slider.addEventListener('mouseleave', startAutoplay);

    goTo(0);
    startAutoplay();
})();

// ===== LANGUAGE TOGGLE (ID <-> EN) =====
const translations = {
    id: {
        nav: {
            home: "Beranda", about: "Tentang", product: "Produk",
            activity: "Aktivitas", article: "Artikel", contact: "Kontak",
            activityDrop: {
                workshop: "Workshop Sourdough",
                cake: "Kelas Dekorasi Kue",
                consult: "Konsultasi Menu",
                all: "Lihat Semua Aktivitas"
            },
            articleDrop: {
                tips: "Tips & Trik",
                inspiration: "Inspirasi",
                recommendation: "Rekomendasi",
                all: "Lihat Semua Artikel"
            }
        },
        hero: {
            slide1: {
                badge: "Segar dari oven setiap hari",
                title: "Harumnya <span class=\"highlight\">Roti</span>, Hangatnya Cerita",
                subtitle: "Nikmati kelezatan roti artisan & kue spesial dari dapur kami"
            },
            slide2: {
                badge: "Kualitas Premium",
                title: "Setiap Gigitan <span class=\"highlight\">Sourdough</span> Bercerita",
                subtitle: "Difermentasi alami selama 24 jam untuk rasa dan tekstur terbaik"
            },
            slide3: {
                badge: "Momen Spesial",
                title: "Kue Custom untuk <span class=\"highlight\">Momen Istimewa</span> Anda",
                subtitle: "Dekorasi cantik, rasa lezat, dibuat khusus untuk acara Anda"
            },
            cta1: "Pesan Sekarang", cta2: "Lihat Produk", cta3: "Selengkapnya", cta4: "Pesan Kue"
        },
        about: {
            tag: "TENTANG",
            heading: "Roti artisan dengan fermentasi alami, dipanggang dengan cinta setiap pagi",
            paragraph: "RotiKita adalah toko roti artisan yang menghadirkan cita rasa autentik dari fermentasi alami. Kami menggunakan bahan baku terbaik dari petani lokal, tanpa pengawet, dan dipanggang segar setiap pagi. Dari sourdough yang renyah hingga croissant yang meleleh di mulut — setiap gigitan adalah cerita.",
            button: "BACA SELENGKAPNYA"
        },
        product: {
            tag: "PRODUK",
            heading: "Temukan Produk Terbaik Kami",
            item1: "Sourdough Classic adalah roti fermentasi alami dengan kulit renyah dan dalam yang lembut. Diproses selama 24 jam dengan ragi liar, menghasilkan rasa asam yang khas dan tekstur yang sempurna. Cocok dinikmati dengan mentega, selai, atau sebagai teman sup favorit Anda.",
            item2: "Croissant Butter adalah pastry klasik Prancis dengan lapisan mentega yang renyah di luar dan lembut di dalam. Dibuat dengan teknik laminasi tradisional, setiap lapisan croissant menghasilkan tekstur yang ringan dan rasa mentega yang kaya. Sempurna untuk sarapan atau camilan sore.",
            item3: "Birthday Cake adalah kue ulang tahun custom yang dibuat spesial untuk momen istimewa Anda. Tersedia berbagai varian rasa seperti cokelat, vanila, red velvet, dan matcha, dengan dekorasi yang dapat disesuaikan dengan tema acara. Pesan minimal H-3 untuk hasil yang sempurna.",
            item4: "Koleksi roti artisan pilihan yang dibuat dengan fermentasi alami dan bahan berkualitas. Tersedia berbagai varian seperti whole wheat, rye, dan multigrain. Setiap roti dipanggang dengan sempurna hingga kulit renyah dan dalam yang lembut. Sempurna untuk sarapan sehat Anda.",
            item5: "Slice Cake adalah potongan kue lezat yang sempurna untuk dinikmati sendiri atau berbagi bersama teman. Tersedia berbagai pilihan rasa seperti cokelat, red velvet, tiramisu, dan matcha, dengan tekstur lembut dan topping yang menggugah selera. Pilihan pas untuk teman minum kopi atau teh sore Anda."
        },
        activity: {
            tag: "AKTIVITAS",
            heading: "Jelajahi Berbagai Aktivitas Menarik Kami",
            item1: { title: "WORKSHOP MEMBUAT SOURDOUGH", text: "Pelajari seni membuat sourdough dari awal hingga matang. Peserta akan diajarkan cara membuat starter, teknik menguleni, fermentasi, dan memanggang sourdough yang sempurna. Cocok untuk pemula yang ingin memulai petualangan roti fermentasi alami." },
            item2: { title: "KELAS DEKORASI KUE", text: "Belajar menghias kue dengan berbagai teknik, dari buttercream piping hingga fondant modeling. Peserta akan dibimbing untuk membuat dekorasi kue yang cantik dan profesional, cocok untuk membuat kue spesial di acara keluarga atau teman." },
            item3: { title: "KONSULTASI MENU FAVORIT", text: "Bingung memilih roti atau kue untuk acara Anda? Tim kami siap memberikan rekomendasi menu terbaik sesuai dengan selera dan kebutuhan Anda, lengkap dengan saran minuman pendamping seperti kopi atau teh hangat." },
            button: "Lihat Semua"
        },
        article: {
            tag: "ARTIKEL",
            readMore: "BACA SELENGKAPNYA",
            heading: "Inspirasi dan Tips untuk Rumah Anda",
            featuredLabel: "Artikel Pilihan",
            item1: { category: "Tips", title: "Tips Menyimpan Roti agar Tetap Segar dan Renyah", text: "Roti sering menjadi lembek jika tidak disimpan dengan benar. Simak cara menyimpan roti yang tepat agar tetap segar, renyah, dan tahan lebih lama tanpa kehilangan cita rasanya di rumah Anda." },
            item2: { category: "Inspirasi", title: "Inspirasi Dekorasi Kue untuk Acara Spesial", text: "Ingin membuat kue yang cantik untuk acara spesial? Simak inspirasi dekorasinya di sini." },
            item3: { category: "Rekomendasi", title: "Rahasia Membuat Roti Tawar Lembut di Rumah", text: "Roti tawar yang lembut dan empuk bisa dibuat sendiri di rumah dengan trik ini." },
            button: "LIHAT SEMUA"
        },
        contact: {
            tag: "KONTAK",
            heading: "Jika Anda memiliki pertanyaan tentang layanan kami, atau hanya ingin tahu lebih lanjut, silakan hubungi kami menggunakan informasi di bawah ini.",
            infoTitle: "Informasi Kontak"
        },
        footer: {
            linksTitle: "Tautan", followTitle: "Ikuti Kami :", articleTitle: "Artikel Kami", marketTitle: "Marketplace Kami"
        }
    },
    en: {
        nav: {
            home: "Home", about: "About", product: "Products",
            activity: "Activities", article: "Articles", contact: "Contact",
            activityDrop: {
                workshop: "Sourdough Workshop",
                cake: "Cake Decorating Class",
                consult: "Menu Consultation",
                all: "View All Activities"
            },
            articleDrop: {
                tips: "Tips & Tricks",
                inspiration: "Inspiration",
                recommendation: "Recommendations",
                all: "View All Articles"
            }
        },
        hero: {
            slide1: {
                badge: "Fresh from the oven every day",
                title: "The Aroma of <span class=\"highlight\">Bread</span>, The Warmth of Stories",
                subtitle: "Enjoy the deliciousness of artisan bread & special cakes from our kitchen"
            },
            slide2: {
                badge: "Premium Quality",
                title: "Every Bite of <span class=\"highlight\">Sourdough</span> Tells a Story",
                subtitle: "Naturally fermented for 24 hours for the best flavor and texture"
            },
            slide3: {
                badge: "Special Moments",
                title: "Custom Cakes for <span class=\"highlight\">Your Special Moments</span>",
                subtitle: "Beautiful decoration, delicious taste, made just for your event"
            },
            cta1: "Order Now", cta2: "View Products", cta3: "Learn More", cta4: "Order a Cake"
        },
        about: {
            tag: "ABOUT",
            heading: "Artisan bread with natural fermentation, baked with love every morning",
            paragraph: "RotiKita is an artisan bakery bringing you the authentic taste of natural fermentation. We use the finest ingredients from local farmers, with no preservatives, baked fresh every morning. From crusty sourdough to melt-in-your-mouth croissants — every bite tells a story.",
            button: "READ MORE"
        },
        product: {
            tag: "PRODUCT",
            heading: "Find Our Best Products",
            item1: "Sourdough Classic is a naturally fermented bread with a crispy crust and soft interior. Processed for 24 hours with wild yeast, resulting in a distinctive tangy flavor and perfect texture. Great with butter, jam, or alongside your favorite soup.",
            item2: "Butter Croissant is a classic French pastry with crisp buttery layers outside and a soft interior. Made with traditional lamination technique, every layer delivers a light texture and rich buttery flavor. Perfect for breakfast or an afternoon snack.",
            item3: "Birthday Cake is a custom cake made specially for your special moments. Available in flavors like chocolate, vanilla, red velvet, and matcha, with decorations that can be customized to your event's theme. Order at least 3 days ahead for the best results.",
            item4: "A curated collection of artisan bread made with natural fermentation and quality ingredients. Available in whole wheat, rye, and multigrain varieties. Every loaf is baked to perfection with a crisp crust and soft interior. Perfect for a healthy breakfast.",
            item5: "Slice Cake is a delicious cake slice perfect to enjoy alone or share with friends. Available in flavors like chocolate, red velvet, tiramisu, and matcha, with a soft texture and irresistible toppings. The perfect match for your coffee or afternoon tea."
        },
        activity: {
            tag: "ACTIVITY",
            heading: "Explore Our Various Interesting Activities",
            item1: { title: "SOURDOUGH MAKING WORKSHOP", text: "Learn the art of making sourdough from start to finish. Participants will be taught how to build a starter, kneading techniques, fermentation, and baking the perfect sourdough. Great for beginners starting their natural fermentation journey." },
            item2: { title: "CAKE DECORATING CLASS", text: "Learn to decorate cakes with various techniques, from buttercream piping to fondant modeling. Participants will be guided to create beautiful, professional cake decorations, perfect for making special cakes for family or friends' events." },
            item3: { title: "FAVORITE MENU CONSULTATION", text: "Not sure which bread or cake to choose for your event? Our team is ready to give you the best menu recommendations tailored to your taste and needs, complete with pairing suggestions like coffee or warm tea." },
            button: "View All"
        },
        article: {
            tag: "ARTICLE",
            readMore: "READ MORE",
            heading: "Inspiration and Tips for Your Home",
            featuredLabel: "Featured Article",
            item1: { category: "Tips", title: "Tips for Keeping Bread Fresh and Crispy", text: "Bread often turns soggy if not stored properly. Here's how to store bread the right way so it stays fresh, crispy, and lasts longer without losing its flavor at home." },
            item2: { category: "Inspiration", title: "Cake Decoration Inspiration for Special Occasions", text: "Want to make a beautiful cake for a special occasion? Check out this decoration inspiration." },
            item3: { category: "Recommendation", title: "The Secret to Soft Homemade White Bread", text: "Soft, fluffy white bread can be made at home yourself with this trick." },
            button: "VIEW ALL"
        },
        contact: {
            tag: "CONTACT",
            heading: "If you have questions about our services, or just want to learn more, please reach out to us using the information below.",
            infoTitle: "Contact Information"
        },
        footer: {
            linksTitle: "Links", followTitle: "Follow Us:", articleTitle: "Our Articles", marketTitle: "Our Marketplace"
        }
    }
};

(function languageToggle() {
    const langBtn = document.getElementById('langToggle');
    const langLabel = document.getElementById('langToggleLabel');
    if (!langBtn) return;

    function getByPath(obj, path) {
        return path.split('.').reduce((acc, key) => (acc && acc[key] !== undefined) ? acc[key] : null, obj);
    }

    function applyLanguage(lang) {
        const dict = translations[lang];
        if (!dict) return;

        document.querySelectorAll('[data-i18n]').forEach(el => {
            const value = getByPath(dict, el.getAttribute('data-i18n'));
            if (typeof value === 'string') el.textContent = value;
        });

        document.querySelectorAll('[data-i18n-html]').forEach(el => {
            const value = getByPath(dict, el.getAttribute('data-i18n-html'));
            if (typeof value === 'string') el.innerHTML = value;
        });

        document.documentElement.setAttribute('lang', lang);
        langLabel.textContent = lang.toUpperCase();
        langBtn.setAttribute('data-current-lang', lang);
        try { localStorage.setItem('rotikita-lang', lang); } catch (e) { /* ignore */ }
    }

    let currentLang = 'id';
    try {
        currentLang = localStorage.getItem('rotikita-lang') || 'id';
    } catch (e) { /* ignore */ }

    applyLanguage(currentLang);

    langBtn.addEventListener('click', () => {
        currentLang = currentLang === 'id' ? 'en' : 'id';
        applyLanguage(currentLang);
    });
})();