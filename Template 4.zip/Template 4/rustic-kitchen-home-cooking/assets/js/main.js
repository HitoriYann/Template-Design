// ============================================================
// AOS INIT
// ============================================================
AOS.init({
  duration: 800,
  once: false,
  offset: 100,
});

// ============================================================
// HEADER SCROLL SHADOW
// ============================================================
window.addEventListener("scroll", function () {
  var header = document.querySelector("header");
  if (window.scrollY > 50) {
    header.classList.add("scrolled");
  } else {
    header.classList.remove("scrolled");
  }
});

// ============================================================
// SLIDER
// ============================================================
const slider = document.getElementById("slider");
const slides = slider.querySelectorAll(".slide");
const dots = document.querySelectorAll("#dots span");
let currentIndex = 0,
  total = slides.length,
  sliderInterval;

function goTo(index) {
  if (index < 0) index = total - 1;
  if (index >= total) index = 0;
  slider.style.transform = "translateX(-" + index * 100 + "%)";
  dots.forEach((dot, i) => dot.classList.toggle("active", i === index));
  slides.forEach((s, i) => s.classList.toggle("active-slide", i === index));
  currentIndex = index;
}

function nextSlide() {
  goTo(currentIndex + 1);
}

function startSlider() {
  sliderInterval = setInterval(nextSlide, 7000);
}

function stopSlider() {
  clearInterval(sliderInterval);
}

dots.forEach((dot, idx) => {
  dot.addEventListener("click", () => {
    stopSlider();
    goTo(idx);
    startSlider();
  });
});

const hero = document.querySelector(".hero-slider");
hero.addEventListener("mouseenter", stopSlider);
hero.addEventListener("mouseleave", startSlider);

goTo(0);
startSlider();

// ============================================================
// SMOOTH SCROLL & ACTIVE NAV
// ============================================================
const navLinks = document.querySelectorAll(
  "nav ul li a:not(.lang-switch button)",
);
const sections = ["home", "about", "product", "activity", "article", "contact"];

function updateActive() {
  let currentSection = "";
  const scrollY = window.scrollY + 100;
  sections.forEach((id) => {
    const el = document.getElementById(id);
    if (el) {
      const top = el.offsetTop;
      const height = el.offsetHeight;
      if (scrollY >= top && scrollY < top + height) currentSection = id;
    }
  });
  navLinks.forEach((link) => {
    link.classList.remove("active");
    if (link.getAttribute("href") === "#" + currentSection)
      link.classList.add("active");
  });
}

navLinks.forEach((link) => {
  link.addEventListener("click", function (e) {
    const targetId = this.getAttribute("href");
    if (targetId.startsWith("#")) {
      e.preventDefault();
      const target = document.querySelector(targetId);
      if (target) {
        const offset = 80;
        const top =
          target.getBoundingClientRect().top + window.pageYOffset - offset;
        window.scrollTo({ top, behavior: "smooth" });
      }
    }
  });
});

window.addEventListener("scroll", updateActive);
updateActive();
