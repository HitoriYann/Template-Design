// OMDIM POP — Fun & Viral Hero Slider Functionality (Hanya Gambar yang Berganti)
let slideIndex = 0;
const imageSlides = document.querySelectorAll('.slide-image-item');
const dots = document.querySelectorAll('.dot');
let slideInterval;

function showSlide(index) {
    if (index >= imageSlides.length) {
        slideIndex = 0;
    } else if (index < 0) {
        slideIndex = imageSlides.length - 1;
    } else {
        slideIndex = index;
    }

    imageSlides.forEach((slide, i) => {
        slide.classList.remove('active');
        if (dots[i]) dots[i].classList.remove('active');
    });

    imageSlides[slideIndex].classList.add('active');
    if (dots[slideIndex]) dots[slideIndex].classList.add('active');
}

function moveSlide(n) {
    showSlide(slideIndex + n);
    resetTimer();
}

function currentSlide(n) {
    showSlide(n);
    resetTimer();
}

function autoSlide() {
    slideIndex++;
    showSlide(slideIndex);
}

function resetTimer() {
    clearInterval(slideInterval);
    slideInterval = setInterval(autoSlide, 5000);
}

// Auto slider timer
slideInterval = setInterval(autoSlide, 5000);

// Hamburger Mobile Menu Toggle
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');

if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
        navMenu.classList.toggle('active');
    });
}

// Close mobile menu on clicking links (but not the dropdown parent toggle itself)
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', (e) => {
        if (link.parentElement.classList.contains('dropdown') && window.innerWidth <= 992) {
            return; // handled by dropdown toggle below
        }
        if (navMenu) navMenu.classList.remove('active');
    });
});

// Toggle Dropdown for Mobile / Touch Devices
const dropdownParent = document.querySelector('.dropdown > a');
if (dropdownParent) {
    dropdownParent.addEventListener('click', (e) => {
        if (window.innerWidth <= 992) {
            e.preventDefault();
            const dropdownMenu = dropdownParent.nextElementSibling;
            if (dropdownMenu) dropdownMenu.classList.toggle('show');
        }
    });
}

// Scroll-reveal: fade + rise elements into view as the user scrolls.
// Content is visible by default in CSS (.reveal has no hidden state on its own),
// so if this script fails to run for any reason, nothing stays hidden.
// JS only opts elements INTO a temporary hidden state, then reveals them —
// plus a failsafe timeout so nothing can stay hidden longer than ~2.5s.
const revealEls = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window && revealEls.length && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    revealEls.forEach(el => el.classList.add('pre-reveal'));

    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.remove('pre-reveal');
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    revealEls.forEach(el => revealObserver.observe(el));

    // Failsafe: never let content stay hidden for long, no matter what.
    setTimeout(() => revealEls.forEach(el => el.classList.remove('pre-reveal')), 2500);
}

// =========================================================
// Multi-language Dictionary — covers the entire page content
// =========================================================
let currentLang = 'id';
const translations = {
    en: {
        // Navbar
        nav_home: "Home",
        nav_about: "About Us",
        nav_menu: 'Menu <i class="fas fa-chevron-down"></i>',
        nav_testimonials: "Testimonials",
        nav_articles: "Articles",
        nav_contact: "Contact",

        // Hero
        hero_badge: "Authentic Since 2018",
        hero_title: 'Exquisite Dimsum, <em>A Legacy of Oriental Flavor</em>',
        hero_desc: "Every steamed delicacy is prepared with a time-honoured recipe and the finest ingredients — bringing a premium dining experience to your family and loved ones.",
        hero_btn: "Order Now",
        hero_social: "<b>5,000+</b> Happy Customers and Counting",
        hero_slide1: "Finest Quality Since 2018",
        hero_slide2: "Today's Special Promo",
        hero_slide3: "Most Loved Dish",

        // About / Philosophy
        about_eyebrow: "Our Philosophy",
        about_title: "A Legacy of Flavor, A Standard of Excellence",
        feature1_title: "100% Fresh Ingredients",
        feature1_desc: "Prepared daily with premium chicken and fresh shrimp, free from preservatives.",
        feature2_title: "Authentic Heritage Recipe",
        feature2_desc: "Premium taste upheld by strict cleanliness and hygiene standards.",
        feature3_title: "Juicy & Perfectly Chewy",
        feature3_desc: "A firm, springy bite served warm for the finest dining experience.",

        // Menu
        menu_eyebrow: "Signature Menu",
        menu_title: "Our Customers' Favorites",
        tag_favorit: "Favorite",
        tag_unggulan: "Signature",
        desc_siomay: "A blend of premium chicken and fresh, quality shrimp.",
        desc_hakau: "Crystal-clear translucent skin filled with whole fresh shrimp.",
        desc_jamur: "Minced chicken paired with the distinct aroma of choice mushrooms.",
        desc_pangsit: "Soft dumplings served in a warm, richly spiced broth.",
        desc_lumpia: "Golden crispy skin filled with minced meat and vegetables.",
        desc_bakpao: "Soft, fluffy steamed bun with a savory filling.",
        btn_order: "Order",

        // Testimonials
        testi_eyebrow: "Customer Reviews",
        testi_title: "What They Say About OMDIM",
        testi1_quote: '"The shrimp hakau is outstanding! The shrimp is truly fresh with a natural sweetness. I\'m a regular now."',
        testi1_role: "Content Creator",
        testi2_quote: '"My kids love the siomay so much, they eat every bite. Thank you, OMDIM!"',
        testi2_role: "Homemaker",
        testi3_quote: '"OMDIM dimsum is always our go-to for family gatherings. The taste has stayed consistent over the years."',
        testi3_role: "Malang Foodie",

        // Articles
        article_eyebrow: "Latest Articles",
        article_title: "Culinary Stories & Insights",
        cat_tips: "Culinary Tips",
        cat_sejarah: "History",
        art1_title: "How to Spot High-Quality Dimsum",
        art1_desc: "Learn the physical signs of fresh dimsum, from aroma to the texture of the skin.",
        art2_title: "The Little-Known Origins of Dimsum",
        art2_desc: "Tracing the journey of this traditional Chinese dish to global fame.",
        read_more: "Read More →",

        // Contact
        contact_eyebrow: "Get In Touch",
        contact_title_top: "Let's Connect With OMDIM",
        contact_left_title: "We're Ready to Serve You",
        contact_left_desc: "Have a question, a special order, or a partnership in mind? Feel free to reach out to us.",
        contact_whatsapp: "+62 811-1111-1111 (WhatsApp Available)",
        contact_hours: "Every Day: 08.00 AM – 08.00 PM (WIB)",
        form_title: "Send a Quick Message",
        form_name: "Your Name",
        form_email: "Your Email",
        form_message: "Write your message or order here...",
        form_submit: "Send Now 🚀",

        // Footer
        footer_desc: "Enjoy premium, high-quality dimsum made with fresh ingredients every day.",
        footer_nav_title: "Navigation",
        footer_help_title: "Help Center",
        footer_copyright: "&copy; 2026 OMDIM. All Rights Reserved."
    },
    id: {
        // Navbar
        nav_home: "Beranda",
        nav_about: "Tentang Kami",
        nav_menu: 'Menu <i class="fas fa-chevron-down"></i>',
        nav_testimonials: "Testimoni",
        nav_articles: "Artikel",
        nav_contact: "Kontak",

        // Hero
        hero_badge: "Autentik Sejak 2018",
        hero_title: 'Kelezatan Dimsum, <em>Warisan Cita Rasa Oriental</em>',
        hero_desc: "Setiap kukusan disiapkan dengan resep turun-temurun dan bahan pilihan — menghadirkan pengalaman bersantap istimewa untuk keluarga dan kerabat Anda.",
        hero_btn: "Pesan Sekarang",
        hero_social: "<b>5.000+</b> Pelanggan Telah Membuktikan",
        hero_slide1: "Kualitas Terbaik Sejak 2018",
        hero_slide2: "Promo Spesial Hari Ini",
        hero_slide3: "Menu Paling Dicari",

        // About / Filosofi
        about_eyebrow: "Filosofi Kami",
        about_title: "Warisan Rasa, Kualitas Istimewa",
        feature1_title: "100% Bahan Segar",
        feature1_desc: "Dibuat setiap hari dari daging ayam pilihan dan udang segar kualitas premium tanpa pengawet.",
        feature2_title: "Resep Otentik Warisan",
        feature2_desc: "Rasa berkualitas tinggi dengan standar kebersihan dan higienitas yang terjaga.",
        feature3_title: "Super Juicy & Kenyal",
        feature3_desc: "Tekstur padat dan kenyal pas di mulut, disajikan hangat untuk pengalaman bersantap terbaik.",

        // Menu
        menu_eyebrow: "Menu Pilihan",
        menu_title: "Sajian Favorit Kami",
        tag_favorit: "Favorit",
        tag_unggulan: "Unggulan",
        desc_siomay: "Perpaduan daging ayam pilihan dan udang segar berkualitas.",
        desc_hakau: "Kulit kristal transparan dengan isian udang utuh segar alami.",
        desc_jamur: "Ayam cincang berpadu dengan aroma khas jamur pilihan.",
        desc_pangsit: "Pangsit lembut disajikan bersama kuah kaldu hangat yang kaya rempah.",
        desc_lumpia: "Kulit renyah keemasan dengan isian daging cincang dan sayuran.",
        desc_bakpao: "Bakpao empuk dengan tekstur lembut dan isian gurih.",
        btn_order: "Pesan",

        // Testimoni
        testi_eyebrow: "Testimoni Pelanggan",
        testi_title: "Apa Kata Mereka Tentang OMDIM",
        testi1_quote: '"Hakau udangnya juara! Udangnya beneran segar dan manis alami. Langsung jadi langganan."',
        testi1_role: "Content Creator",
        testi2_quote: '"Anak-anak suka banget sama siomaynya, jadi lahap makannya. Terima kasih OMDIM!"',
        testi2_role: "Ibu Rumah Tangga",
        testi3_quote: '"Dimsum OMDIM selalu jadi andalan kumpul keluarga. Rasanya konsisten dari dulu."',
        testi3_role: "Foodie Malang",

        // Artikel
        article_eyebrow: "Artikel Terbaru",
        article_title: "Cerita & Wawasan Kuliner",
        cat_tips: "Tips Kuliner",
        cat_sejarah: "Sejarah",
        art1_title: "Tips Memilih Dimsum yang Berkualitas Tinggi",
        art1_desc: "Kenali ciri fisik dimsum segar mulai dari aroma hingga tekstur kulitnya.",
        art2_title: "Asal-usul Dimsum yang Belum Banyak Diketahui",
        art2_desc: "Menelusuri perjalanan kuliner tradisional Tiongkok hingga mendunia.",
        read_more: "Baca Selengkapnya →",

        // Kontak
        contact_eyebrow: "Kontak Kami",
        contact_title_top: "Mari Terhubung dengan OMDIM",
        contact_left_title: "Kami Siap Melayani Anda",
        contact_left_desc: "Punya pertanyaan, pesanan khusus, atau ingin bekerja sama? Jangan ragu untuk menghubungi kami.",
        contact_whatsapp: "+62 811-1111-1111 (WhatsApp Ready)",
        contact_hours: "Setiap Hari: 08.00 – 20.00 WIB",
        form_title: "Kirim Pesan Singkat",
        form_name: "Nama Kamu",
        form_email: "Email Kamu",
        form_message: "Tulis pesan atau pesananmu di sini...",
        form_submit: "Kirim Sekarang 🚀",

        // Footer
        footer_desc: "Nikmati kelezatan dimsum premium berkualitas tinggi dengan bahan segar setiap hari.",
        footer_nav_title: "Navigasi",
        footer_help_title: "Pusat Bantuan",
        footer_copyright: "&copy; 2026 OMDIM. Hak Cipta Dilindungi Undang-Undang."
    }
};

function toggleLang() {
    currentLang = currentLang === 'id' ? 'en' : 'id';
    document.getElementById('langLabel').innerText = currentLang === 'id' ? 'EN' : 'ID';

    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[currentLang][key] !== undefined) {
            el.innerHTML = translations[currentLang][key];
        }
    });

    document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
        const key = el.getAttribute('data-i18n-placeholder');
        if (translations[currentLang][key] !== undefined) {
            el.setAttribute('placeholder', translations[currentLang][key]);
        }
    });

    document.documentElement.lang = currentLang;
}