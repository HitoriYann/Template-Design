// ====================================================
// 1. HAMBURGER MENU (gaya rotikita-web)
// ====================================================
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');

if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        hamburger.classList.toggle('active');
    });

    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            hamburger.classList.remove('active');
        });
    });
}

// ====================================================
// 1b. DROPDOWN NAVBAR — toggle di mobile
//     Di desktop, dropdown muncul via CSS :hover.
//     Di mobile (≤768px), klik pada .dropdown-toggle
//     menambahkan class .open pada <li class="has-dropdown">.
// ====================================================
document.querySelectorAll('.dropdown-toggle').forEach(toggle => {
    toggle.addEventListener('click', function (e) {
        // Hanya jalankan di tampilan mobile
        if (window.innerWidth > 768) return;

        e.preventDefault(); // Cegah scroll ke #anchor saat expand
        const parentLi = this.closest('.has-dropdown');
        const isOpen = parentLi.classList.contains('open');

        // Tutup semua dropdown lain yang terbuka
        document.querySelectorAll('.has-dropdown.open').forEach(el => {
            if (el !== parentLi) el.classList.remove('open');
        });

        // Toggle dropdown ini
        parentLi.classList.toggle('open', !isOpen);
        this.setAttribute('aria-expanded', String(!isOpen));
    });
});

// Tutup dropdown (mobile) saat item submenu diklik
document.querySelectorAll('.dropdown-link').forEach(link => {
    link.addEventListener('click', () => {
        document.querySelectorAll('.has-dropdown.open').forEach(el => {
            el.classList.remove('open');
        });
        // Tutup juga nav-menu mobile
        if (navMenu) navMenu.classList.remove('active');
        if (hamburger) hamburger.classList.remove('active');
    });
});

// Tutup dropdown saat klik di luar navbar (desktop)
document.addEventListener('click', function (e) {
    if (!e.target.closest('.nav-menu')) {
        document.querySelectorAll('.has-dropdown.open').forEach(el => {
            el.classList.remove('open');
        });
    }
});


// ====================================================
// 2. ACTIVE NAV LINK ON SCROLL
// ====================================================
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');

window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 120;
        if (window.scrollY >= sectionTop) {
            current = section.getAttribute('id');
        }
    });

    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// ====================================================
// 3. BAHASA TOGGLE (ID/EN)
// ====================================================
const translations = {
    id: {
        nav_home: 'Beranda',
        nav_tentang: 'Tentang',
        nav_produk: 'Produk',
        nav_artikel: 'Artikel',
        nav_artikel_blog: 'Blog',
        nav_artikel_tips: 'Tips & Perawatan Kuku',
        nav_artikel_inspirasi: 'Inspirasi Desain',
        nav_contact: 'Kontak',
        nav_book: 'Booking',
        hero_eyebrow: 'Nail Art Studio',
        hero_title1: 'Setiap Jari,',
        hero_title2: 'Punya Cerita',
        hero_desc: 'Studio nail art butik dengan sentuhan personal — manicure, gel polish, ekstensi, hingga desain custom, dikerjakan nail artist berpengalaman dengan produk premium.',
        hero_btn1: 'Booking Sekarang',
        hero_btn2: 'Lihat Layanan',
        hero_scroll: 'SCROLL',
        card1_title: 'No. 01 — Manicure',
        card1_desc: 'Perawatan dasar',
        card2_title: 'No. 02 — Gel Polish',
        card2_desc: 'Tahan 3 minggu',
        card3_title: 'No. 03 — Extension',
        card3_desc: 'Kuat & rapi',
        card4_title: 'No. 04 — Nail Art',
        card4_desc: 'Desain custom',
        readMore: 'Baca Selengkapnya',
        products_tag: 'Galeri',
        products_title: 'Etalase Nail Art',
        products_desc: 'Koleksi desain favorit klien kami — siap jadi inspirasi untuk kunjunganmu berikutnya.',
        gallery1: 'Nail Art Klasik',
        gallery1_desc: 'Desain klasik dengan garis rapi dan warna netral, cocok untuk tampilan sehari-hari yang tetap elegan.',
        gallery2: 'Gel Polish',
        gallery2_desc: 'Lapisan gel glossy tahan lama hingga 3 minggu tanpa mengurangi kilau alami kuku.',
        gallery3: 'Nail Extension',
        gallery3_desc: 'Ekstensi kuku rapi dan kokoh, dibentuk sesuai gaya yang kamu inginkan.',
        gallery4: 'French Manicure',
        gallery4_desc: 'Sentuhan klasik nan elegan dengan ujung putih bersih khas French manicure.',
        gallery5: 'Nail Spa & Pedikur',
        gallery5_desc: 'Perawatan kaki menyeluruh dengan pijatan relaksasi dan hasil kuku yang halus.',
        gallery6: 'Nail Art Bridal',
        gallery6_desc: 'Desain istimewa untuk hari pernikahan, detail elegan yang tahan sepanjang acara.',
        contact_tag: 'Kontak',
        contact_title: 'Ada pertanyaan seputar layanan kami? Hubungi kami lewat informasi di bawah ini.',
        contact_info_title: 'Informasi Kontak',
        contact_address: 'Jl. Danau Amora No.C5 E8, Sawojajar, 1, Kota Malang, Jawa Timur 65138',
        footer_links: 'Tautan',
        footer_follow: 'Ikuti Kami :',
        footer_articles: 'Tips Perawatan',
        footer_marketplace: 'Marketplace kami',
        article_tips: 'Tips & Trik',
        article_inspiration: 'Inspirasi',
        article_recommendation: 'Rekomendasi',
        footer_copyright: '© 2026 Setiap Detik Punya Cerita. Hak Cipta Dilindungi.',
        footer_email: 'Email: elecompindonesia.com'
    },
    en: {
        nav_home: 'Home',
        nav_tentang: 'About',
        nav_produk: 'Products',
        nav_artikel: 'Articles',
        nav_artikel_blog: 'Blog',
        nav_artikel_tips: 'Nail Care Tips',
        nav_artikel_inspirasi: 'Design Inspiration',
        nav_contact: 'Contact',
        nav_book: 'Book Now',
        hero_eyebrow: 'Nail Art Studio',
        hero_title1: 'Every Finger,',
        hero_title2: 'Has a Story',
        hero_desc: 'A boutique nail art studio with a personal touch — manicure, gel polish, extensions, and custom designs, done by experienced nail artists with premium products.',
        hero_btn1: 'Book Now',
        hero_btn2: 'View Services',
        hero_scroll: 'SCROLL',
        card1_title: 'No. 01 — Manicure',
        card1_desc: 'Basic care',
        card2_title: 'No. 02 — Gel Polish',
        card2_desc: 'Lasts 3 weeks',
        card3_title: 'No. 03 — Extension',
        card3_desc: 'Strong & neat',
        card4_title: 'No. 04 — Nail Art',
        card4_desc: 'Custom design',
        readMore: 'Read More',
        products_tag: 'Gallery',
        products_title: 'Nail Art Showcase',
        products_desc: 'Our clients\' favorite designs — ready to inspire your next visit.',
        gallery1: 'Classic Nail Art',
        gallery1_desc: 'A classic design with clean lines and neutral tones, perfect for an elegant everyday look.',
        gallery2: 'Gel Polish',
        gallery2_desc: 'A long-lasting glossy gel finish that keeps its shine for up to three weeks.',
        gallery3: 'Nail Extension',
        gallery3_desc: 'Neat, sturdy nail extensions shaped exactly the way you want.',
        gallery4: 'French Manicure',
        gallery4_desc: 'A timeless, elegant touch with the crisp white tips of a classic French manicure.',
        gallery5: 'Nail Spa & Pedicure',
        gallery5_desc: 'A complete foot treatment with a relaxing massage and beautifully smooth nails.',
        gallery6: 'Bridal Nail Art',
        gallery6_desc: 'A special design for your wedding day, with elegant detail that lasts through the whole celebration.',
        contact_tag: 'Contact',
        contact_title: 'Have questions about our services? Reach out to us via the information below.',
        contact_info_title: 'Contact Information',
        contact_address: 'Jl. Danau Amora No.C5 E8, Sawojajar, 1, Kota Malang, East Java 65138',
        footer_links: 'Links',
        footer_follow: 'Follow Us :',
        footer_articles: 'Care Tips',
        footer_marketplace: 'Our Marketplace',
        article_tips: 'Tips & Tricks',
        article_inspiration: 'Inspiration',
        article_recommendation: 'Recommendations',
        footer_copyright: '© 2026 Every Moment Has a Story. All Rights Reserved.',
        footer_email: 'Email: elecompindonesia.com'
    }
};

const langToggle = document.getElementById('langToggle');
const langToggleLabel = document.getElementById('langToggleLabel');
let currentLang = 'id';

function setLanguage(lang) {
    currentLang = lang;
    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[lang] && translations[lang][key]) {
            el.textContent = translations[lang][key];
        }
    });
    if (langToggleLabel) langToggleLabel.textContent = lang.toUpperCase();
    document.documentElement.setAttribute('lang', lang);
}

if (langToggle) {
    langToggle.addEventListener('click', () => {
        setLanguage(currentLang === 'id' ? 'en' : 'id');
    });
}

// ====================================================
// 4. SMOOTH SCROLL
// ====================================================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href === '#') return;
        const target = document.querySelector(href);
        if (target) {
            e.preventDefault();
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// ====================================================
// 5. INIT
// ====================================================
setLanguage('id');