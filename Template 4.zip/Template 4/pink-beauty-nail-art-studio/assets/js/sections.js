// ============================================================
// sections.js — Pink Beauty · Nail Art Studio
// Fitur: Scroll Reveal · Count-up · Filter Produk · Tab Aktivitas
// Semua vanilla JS, tanpa library eksternal.
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

    // ──────────────────────────────────────────────
    // 1. SCROLL REVEAL — IntersectionObserver
    //    Tambahkan class .visible ke semua .reveal*
    //    saat elemen masuk viewport
    // ──────────────────────────────────────────────
    const revealEls = document.querySelectorAll(
        '.reveal, .reveal-left, .reveal-right'
    );

    if (revealEls.length > 0) {
        const revealObserver = new IntersectionObserver(
            (entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        // Hentikan pengamatan setelah reveal sekali
                        revealObserver.unobserve(entry.target);
                    }
                });
            },
            { threshold: 0.12 }
        );
        revealEls.forEach(el => revealObserver.observe(el));
    }

    // ──────────────────────────────────────────────
    // 2. COUNT-UP ANIMATION — stats di section Tentang
    //    Elemen target: .stat-num[data-target]
    //    Dipicu sekali saat .tentang-stats masuk viewport
    // ──────────────────────────────────────────────
    function animateCountUp(el, target, duration = 1800) {
        let start = 0;
        const step = target / (duration / 16); // ~60fps
        const tick = () => {
            start += step;
            if (start >= target) {
                el.textContent = target.toLocaleString('id-ID');
                return;
            }
            el.textContent = Math.floor(start).toLocaleString('id-ID');
            requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
    }

    const statsSection = document.querySelector('.tentang-stats');
    if (statsSection) {
        let triggered = false;
        const statsObserver = new IntersectionObserver(
            (entries) => {
                if (entries[0].isIntersecting && !triggered) {
                    triggered = true;
                    document.querySelectorAll('.stat-num').forEach(el => {
                        const target = parseInt(el.getAttribute('data-target'), 10);
                        if (!isNaN(target)) animateCountUp(el, target);
                    });
                    statsObserver.unobserve(statsSection);
                }
            },
            { threshold: 0.4 }
        );
        statsObserver.observe(statsSection);
    }

    // ──────────────────────────────────────────────
    // 3. FILTER PRODUK — klik tab → tampilkan / sembunyikan card
    //    Tiap .produk-card punya attribute data-cat="nail-art" dll.
    //    Tombol filter punya attribute data-filter="nail-art" dll.
    //    "semua" = tampilkan semua card
    // ──────────────────────────────────────────────
    const filterBtns = document.querySelectorAll('.filter-btn');
    const produkCards = document.querySelectorAll('.produk-card');

    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            // Update state tombol aktif
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filter = btn.getAttribute('data-filter');

            produkCards.forEach(card => {
                const cat = card.getAttribute('data-cat');
                if (filter === 'semua' || cat === filter) {
                    card.classList.remove('hidden');
                    // Animasi masuk kecil
                    card.style.animation = 'none';
                    requestAnimationFrame(() => {
                        card.style.animation = 'fadeInCard 0.35s ease forwards';
                    });
                } else {
                    card.classList.add('hidden');
                }
            });
        });
    });



    // ──────────────────────────────────────────────
    // 5. KEYFRAME ANIMASI untuk filter card (inject via JS)
    // ──────────────────────────────────────────────
    const styleSheet = document.createElement('style');
    styleSheet.textContent = `
        @keyframes fadeInCard {
            from { opacity: 0; transform: translateY(16px) scale(0.97); }
            to   { opacity: 1; transform: translateY(0) scale(1); }
        }
    `;
    document.head.appendChild(styleSheet);

});
