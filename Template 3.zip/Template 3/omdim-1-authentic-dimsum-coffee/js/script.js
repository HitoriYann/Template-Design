// =========================================================
// OMDIM — Modern Artisanal Minimalist Script (Pro Edition)
// Features: Dynamic Scroll Progress, Tilt FX, Steam Canvas Particle System,
// i18n Multi-language, Observer Scroll Reveal, and Counter Animations.
// =========================================================

'use strict';

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// =========================================================
// 1. SCROLL PROGRESS & HEADER SCROLL
// =========================================================
const header = document.getElementById('header');
const scrollProgress = document.getElementById('scrollProgress');

function handleScroll() {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const scrollPercent = (scrollTop / docHeight) * 100;

    if (scrollProgress) {
        scrollProgress.style.width = `${scrollPercent}%`;
    }

    if (scrollTop > 25) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
}

window.addEventListener('scroll', handleScroll, { passive: true });
handleScroll();

// =========================================================
// 2. MOBILE MENU & OVERLAY ACCESSIBILITY
// =========================================================
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');
const navOverlay = document.getElementById('navOverlay');

function closeMobileMenu() {
    if (!navMenu) return;
    navMenu.classList.remove('active');
    navOverlay.classList.remove('active');
    hamburger.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
}

function openMobileMenu() {
    if (!navMenu) return;
    navMenu.classList.add('active');
    navOverlay.classList.add('active');
    hamburger.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
}

if (hamburger) {
    hamburger.addEventListener('click', () => {
        const isOpen = navMenu.classList.contains('active');
        isOpen ? closeMobileMenu() : openMobileMenu();
    });
}

if (navOverlay) {
    navOverlay.addEventListener('click', closeMobileMenu);
}

// Fixed link click handling for menu item sublinks
document.querySelectorAll('.nav-list a').forEach(link => {
    link.addEventListener('click', (e) => {
        const isDropdownTrigger = link.parentElement.classList.contains('dropdown');
        if (isDropdownTrigger && window.innerWidth <= 768) {
            e.preventDefault();
            link.parentElement.classList.toggle('active');
            return;
        }
        if (window.innerWidth <= 768) {
            closeMobileMenu();
        }
    });
});

window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        closeMobileMenu();
        const activeDropdown = document.querySelector('.dropdown.active');
        if (activeDropdown) activeDropdown.classList.remove('active');
    }
});

// =========================================================
// 3. ENHANCED STEAMER HERO SLIDER
// =========================================================
let slideIndex = 0;
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');
let sliderTimer = null;

function showSlide(n) {
    if (!slides.length) return;
    slides.forEach(slide => slide.classList.remove('active'));
    dots.forEach(dot => dot.classList.remove('active'));

    slideIndex = n;
    if (slideIndex >= slides.length) slideIndex = 0;
    if (slideIndex < 0) slideIndex = slides.length - 1;

    slides[slideIndex].classList.add('active');
    if (dots[slideIndex]) dots[slideIndex].classList.add('active');
}

function moveSlide(n) {
    showSlide(slideIndex + n);
}

function currentSlide(n) {
    showSlide(n);
}

function startSlider() {
    if (prefersReducedMotion) return;
    stopSlider();
    sliderTimer = setInterval(() => moveSlide(1), 5000);
}

function stopSlider() {
    if (sliderTimer) clearInterval(sliderTimer);
}

startSlider();

const steamerEl = document.querySelector('.steamer-container');
if (steamerEl) {
    steamerEl.addEventListener('mouseenter', stopSlider);
    steamerEl.addEventListener('mouseleave', startSlider);
    steamerEl.addEventListener('touchstart', stopSlider, { passive: true });
}

// =========================================================
// 4. CANVAS DYNAMIC STEAM PARTICLES
// =========================================================
const canvas = document.getElementById('steamCanvas');
if (canvas && !prefersReducedMotion) {
    const ctx = canvas.getContext('2d');
    let particles = [];

    function resizeCanvas() {
        const rect = canvas.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
    }
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    class Particle {
        constructor() {
            this.reset();
        }
        reset() {
            this.x = canvas.width * 0.3 + Math.random() * (canvas.width * 0.4);
            this.y = canvas.height * 0.7;
            this.radius = 8 + Math.random() * 16;
            this.vy = -(0.4 + Math.random() * 0.8);
            this.vx = (Math.random() - 0.5) * 0.4;
            this.alpha = 0.05 + Math.random() * 0.25;
            this.life = 0;
            this.maxLife = 120 + Math.random() * 80;
        }
        update() {
            this.x += this.vx;
            this.y += this.vy;
            this.life++;
            this.radius += 0.15;
            if (this.life > this.maxLife || this.y < 0) {
                this.reset();
            }
        }
        draw() {
            const currentAlpha = this.alpha * (1 - this.life / this.maxLife);
            ctx.save();
            ctx.beginPath();
            const grad = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.radius);
            grad.addColorStop(0, `rgba(250, 246, 240, ${currentAlpha})`);
            grad.addColorStop(1, 'rgba(250, 246, 240, 0)');
            ctx.fillStyle = grad;
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }
    }

    for (let i = 0; i < 22; i++) {
        const p = new Particle();
        p.life = Math.random() * p.maxLife; // stagger initial positions
        particles.push(p);
    }

    function animateSteam() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            p.update();
            p.draw();
        });
        requestAnimationFrame(animateSteam);
    }
    animateSteam();
}

// =========================================================
// 5. 3D TILT EFFECT ON CARDS / STEAMER
// =========================================================
if (!prefersReducedMotion && window.innerWidth > 900) {
    const tiltElements = document.querySelectorAll('.js-tilt');
    tiltElements.forEach(el => {
        el.addEventListener('mousemove', (e) => {
            const rect = el.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            const rotateX = ((y - centerY) / centerY) * -8;
            const rotateY = ((x - centerX) / centerX) * 8;

            el.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
            el.style.transition = 'transform 0.1s ease-out';
        });

        el.addEventListener('mouseleave', () => {
            el.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)';
            el.style.transition = 'transform 0.6s var(--ease)';
        });
    });
}

// =========================================================
// 6. OBSERVER SCROLL REVEAL & NAV HIGHLIGHT
// =========================================================
const revealEls = document.querySelectorAll('.reveal');

if (prefersReducedMotion || !('IntersectionObserver' in window)) {
    revealEls.forEach(el => el.classList.add('is-visible'));
} else {
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    revealEls.forEach(el => revealObserver.observe(el));
}

// Section Nav Highlight
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-link');

if (sections.length && 'IntersectionObserver' in window) {
    const navObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const id = entry.target.getAttribute('id');
                navLinks.forEach(link => {
                    const href = link.getAttribute('href');
                    link.classList.toggle('active', href === `#${id}`);
                });
            }
        });
    }, { rootMargin: '-35% 0px -55% 0px', threshold: 0 });

    sections.forEach(sec => navObserver.observe(sec));
}

// =========================================================
// 7. COUNTER ANIMATION FOR ABOUT STATS
// =========================================================
const statNumbers = document.querySelectorAll('.stat .num');

function formatStat(value, format) {
    if (format === 'plus') return Math.round(value).toLocaleString('id-ID') + '+';
    if (format === 'decimal') return value.toFixed(1);
    return Math.round(value).toLocaleString('id-ID');
}

function animateCounter(el) {
    const target = parseFloat(el.getAttribute('data-count'));
    const format = el.getAttribute('data-format') || 'int';
    const duration = 1600;
    const start = performance.now();

    function tick(now) {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        const current = target * eased;
        el.textContent = formatStat(current, format);
        if (progress < 1) requestAnimationFrame(tick);
        else el.textContent = formatStat(target, format);
    }
    requestAnimationFrame(tick);
}

if (statNumbers.length) {
    if (prefersReducedMotion || !('IntersectionObserver' in window)) {
        statNumbers.forEach(el => {
            const target = parseFloat(el.getAttribute('data-count'));
            el.textContent = formatStat(target, el.getAttribute('data-format') || 'int');
        });
    } else {
        const statObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        statNumbers.forEach(el => statObserver.observe(el));
    }
}

// =========================================================
// 8. WHATSAPP DIRECT FORM HANDLER
// =========================================================
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('fname').value;
        const contact = document.getElementById('femail').value;
        const msg = document.getElementById('fmsg').value;

        const phone = '62811111111'; // Nomor WA OMDIM
        const text = `Halo OMDIM, saya ${name} (${contact}).\n\nPesan/Pesanan saya:\n${msg}`;
        
        window.open(`https://wa.me/${phone}?text=${encodeURIComponent(text)}`, '_blank');
    });
}

// =========================================================
// 9. MULTI-LANGUAGE (i18n)
// =========================================================
const translations = {
    "id": {
        "nav_home": "Beranda", "nav_about": "Tentang Kami", "nav_menu": "Menu",
        "nav_testimonials": "Testimoni", "nav_articles": "Artikel", "nav_contact": "Kontak",
        "hero_eyebrow": "Dimsum Rumahan · Sejak 2018",
        "hero_title": "Rasa yang Diwariskan,<br><span class=\"gradient-text\">Segar Setiap Hari</span>",
        "hero_desc": "OMDIM menghadirkan dimsum otentik bermutu tinggi dengan resep warisan sejak 2018. Dibuat tanpa bahan pengawet, penuh kehangatan & cinta di setiap lipatan.",
        "hero_cta_menu": "Lihat Menu", "hero_cta_about": "Tentang Kami",
        "about_sub": "Tentang Kami", "about_title": "Kisah Dapur OMDIM Sejak 2018",
        "about_p1": "OMDIM lahir dari dedikasi mendalam untuk menghadirkan kehangatan dimsum buatan rumah dengan standar rasa profesional. Sejak 2018, kami menjaga keaslian resep dan proses pembuatan manual.",
        "about_p2": "Dimulai dari dapur keluarga kecil di Malang, kini OMDIM menjadi santapan favorit ribuan penikmat kuliner. Janji kami tetap sama: ketersediaan bahan paling segar, kebersihan terjamin, dan tanpa bahan pengawet sintetik.",
        "stat_year": "Tahun Berdiri", "stat_customers": "Pelanggan Setia", "stat_rating": "Rating Kepuasan",
        "menu_sub": "Menu Andalan", "menu_title": "6 Varian Favorit OMDIM",
        "menu_siomay": "Siomay klasik dengan isian padat daging ayam dan udang segar pilihan, juicy dan kenyal.",
        "menu_hakau": "Kulit tipis lembut berisi udang utuh segar yang garing dan manis alami.",
        "menu_jamur": "Perpaduan gurihnya ayam dan jamur segar pilihan yang kaya rasa & tekstur.",
        "menu_pangsit": "Pangsit lembut nan gurih disajikan bersama kuah kaldu hangat yang kaya rempah.",
        "menu_lumpia": "Lumpia renyah berbalut kulit tahu dengan isian ayam berumbu spesial.",
        "menu_bakpao": "Bakpao empuk dan lembut bertekstur kapas dengan isian isi ayam pedas gurih.",
        "testimonial_sub": "Testimoni Suara Pelanggan", "testimonial_title": "Apa Kata Mereka Tentang OMDIM?",
        "testimonial_1": '"Dimsum OMDIM selalu jadi langganan kalau ada arisan keluarga. Dagingnya terasa banget, bukan sekadar tepung!"',
        "testimonial_2": '"Hakau udangnya luar biasa! Udangnya utuh, terasa manis segar dan kulitnya tidak gampang sobek."',
        "testimonial_3": '"Anak-anak saya yang tadinya pemilih makanan langsung suka banget. Sekali pesan langsung ludes!"',
        "testimonial_4": '"Kualitas rasa setara resto bintang lima tapi harga sangat ramah kantong. Recommended banget!"',
        "customer_since": "Pelanggan Sejak 2019", "customer_foodie": "Foodie Malang", "customer_mom": "Ibu Rumah Tangga", "customer_content": "Content Creator",
        "articles_sub": "Artikel & Edukasi", "articles_title": "Cerita & Inspiration OMDIM",
        "article1_title": "Tips Memilih Dimsum Segar & Berkualitas High-Grade", "article1_desc": "Kenali ciri-ciri visual dan kenikmatan rasa dimsum tanpa pengawet sebelum Anda membelinya.",
        "article2_title": "Asal-usul Seni Dimsum dari Kedai Teh Kuno", "article2_desc": "Menjelajahi perjalanan tradisi Yum Cha hingga berkembang menjadi hidangan global kegemaran semua orang.",
        "article_read": "Baca Selengkapnya",
        "contact_sub": "Hubungi Kami", "contact_title": "Layanan Pesanan & Pertanyaan",
        "contact_address_label": "Alamat Dapur Utama", "contact_address": "Jl. Danau Bratan Tim. No.H5 A5, Madyopuro, Kec. Kedungkandang, Kota Malang, Jawa Timur 65139",
        "contact_phone_label": "Telepon & WhatsApp Direct", "contact_email_label": "Email Resmi", "contact_hours_label": "Jam Operasional", "contact_hours": "Buka Setiap Hari, 08.00 – 20.00 WIB",
        "form_name": "Nama Lengkap Anda", "form_email": "Email / Nomor WA", "form_message": "Pesan / Detail Pesanan...", "form_submit": "Kirim Pesan WhatsApp",
        "footer_desc": "Dimsum rumahan bermutu tinggi dengan konsistensi resep khas sejak 2018. Disajikan hangat & segar setiap hari.",
        "footer_nav": "Navigasi Utama", "footer_contact": "Hubungi Langsung", "footer_address": "Malang, Jawa Timur, Indonesia", "footer_rights": "Hak Cipta Dilindungi Undang-Undang."
    },
    "en": {
        "nav_home": "Home", "nav_about": "About Us", "nav_menu": "Menu",
        "nav_testimonials": "Testimonials", "nav_articles": "Articles", "nav_contact": "Contact",
        "hero_eyebrow": "Homemade Dimsum · Since 2018",
        "hero_title": "A Legacy of Taste,<br><span class=\"gradient-text\">Fresh Every Day</span>",
        "hero_desc": "OMDIM serves high-grade authentic dimsum with a heritage recipe since 2018. Made with zero preservatives, wrapped with warmth & passion.",
        "hero_cta_menu": "Explore Menu", "hero_cta_about": "About Us",
        "about_sub": "About Us", "about_title": "The Story of OMDIM Kitchen Since 2018",
        "about_p1": "OMDIM was born from a deep commitment to bringing home-style dimsum comfort paired with professional culinary excellence. Since 2018, we preserve authentic artisan recipes.",
        "about_p2": "Starting from a small family kitchen in Malang, OMDIM has grown into a cherished favorite for thousands. Our promise remains: freshest ingredients, pristine hygiene, and no synthetic preservatives.",
        "stat_year": "Established", "stat_customers": "Loyal Customers", "stat_rating": "Rating Score",
        "menu_sub": "Signature Menu", "menu_title": "6 OMDIM Favorite Dishes",
        "menu_siomay": "Classic juicy dimsum filled with dense premium chicken and fresh shrimp.",
        "menu_hakau": "Delicate translucent skin with whole fresh crispy naturally sweet shrimp.",
        "menu_jamur": "Savory harmony of tender chicken and fresh selected mushrooms.",
        "menu_pangsit": "Soft poached dumplings served in warm aromatic chicken herb broth.",
        "menu_lumpia": "Crispy bean-curd skin rolls filled with specially seasoned chicken.",
        "menu_bakpao": "Cloud-soft steamed buns filled with savory spicy chicken.",
        "testimonial_sub": "Customer Reviews", "testimonial_title": "What They Say About OMDIM?",
        "testimonial_1": '"OMDIM dimsum is always our family favorite for gatherings. Real packed meat, not just flour!"',
        "testimonial_2": '"The shrimp hakau is incredible! Whole juicy fresh shrimp and delicate skin."',
        "testimonial_3": '"My picky eater kids instantly loved it. A single order vanishes in minutes!"',
        "testimonial_4": '"Five-star restaurant quality at super friendly prices. Highly recommended!"',
        "customer_since": "Customer Since 2019", "customer_foodie": "Malang Foodie", "customer_mom": "Homemaker", "customer_content": "Content Creator",
        "articles_sub": "Articles & Guides", "articles_title": "Stories & Inspiration from OMDIM",
        "article1_title": "Tips for Choosing Fresh High-Grade Artisanal Dimsum", "article1_desc": "Learn key visual indicators and flavor profiles of authentic fresh dimsum.",
        "article2_title": "The Origin of Dimsum Art from Ancient Tea Houses", "article2_desc": "Exploring the historical journey of Yum Cha traditions into a global culinary icon.",
        "article_read": "Read Full Story",
        "contact_sub": "Contact Us", "contact_title": "Order Inquiries & Support",
        "contact_address_label": "Main Kitchen Address", "contact_address": "Jl. Danau Bratan Tim. No.H5 A5, Madyopuro, Malang, East Java 65139",
        "contact_phone_label": "Phone & Direct WhatsApp", "contact_email_label": "Official Email", "contact_hours_label": "Kitchen Hours", "contact_hours": "Open Daily, 08.00 AM – 08.00 PM",
        "form_name": "Your Full Name", "form_email": "Email or WhatsApp No.", "form_message": "Message / Order Details...", "form_submit": "Send via WhatsApp",
        "footer_desc": "High-grade artisanal dimsum with consistent heritage recipes since 2018. Served hot & fresh daily.",
        "footer_nav": "Main Navigation", "footer_contact": "Direct Contact", "footer_address": "Malang, East Java, Indonesia", "footer_rights": "All Rights Reserved."
    }
};

let currentLang = 'id';

function toggleLang() {
    const btn = document.getElementById('langLabel');
    currentLang = currentLang === 'id' ? 'en' : 'id';
    if (btn) btn.innerText = currentLang === 'id' ? 'EN' : 'ID';

    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (translations[currentLang] && translations[currentLang][key]) {
            const translationText = translations[currentLang][key];

            if (el.querySelector('.nav-arrow')) {
                const textSpan = el.querySelector('span') || el;
                textSpan.innerText = translationText;
            } else if (translationText.includes('<')) {
                el.innerHTML = translationText;
            } else {
                const innerSpan = el.querySelector('span');
                if (innerSpan) {
                    innerSpan.innerText = translationText;
                } else {
                    el.innerText = translationText;
                }
            }
        }
    });
}